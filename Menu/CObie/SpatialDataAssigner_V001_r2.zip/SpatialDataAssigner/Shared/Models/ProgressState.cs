using CommunityToolkit.Mvvm.ComponentModel;

namespace Revit26_Plugin.Shared.Models
{
    /// <summary>
    /// Shared progress/cancel state for long-running tool operations.
    /// Bound by the fixed footer of every tool window (ProgressBar + counter + Cancel).
    ///
    /// Usage contract:
    ///   - UI thread sets IsRunning / Total before the ExternalEvent is raised.
    ///   - The Revit-side handler calls Report(current, item) as it walks elements.
    ///   - The Cancel button sets IsCancelling; the handler polls IsCancelling
    ///     and rolls the TransactionGroup back when it is set.
    ///
    /// NOTE: Report() is called from the Revit API thread, which in Revit is the
    /// same thread as the WPF UI thread (external events execute on it). The
    /// handler must pump the dispatcher periodically or the window will not repaint
    /// and the Cancel button will never receive a click. See SpatialResolveEngine.
    /// </summary>
    public partial class ProgressState : ObservableObject
    {
        [ObservableProperty]
        private bool _isRunning;

        [ObservableProperty]
        private bool _isCancelling;

        [ObservableProperty]
        private int _current;

        [ObservableProperty]
        private int _total;

        [ObservableProperty]
        private string _currentItem = string.Empty;

        [ObservableProperty]
        private string _statusText = "Ready";

        /// <summary>0-100. Guarded against Total = 0.</summary>
        public double Percent => Total <= 0 ? 0d : (Current * 100d) / Total;

        /// <summary>"1,247 / 8,903 · 14%" — bound OneWay to the footer counter.</summary>
        public string CounterText => Total <= 0
            ? "0 / 0"
            : $"{Current:N0} / {Total:N0} · {Percent:F0}%";

        /// <summary>True only while a run is active and cancellation has not been requested.</summary>
        public bool CanCancel => IsRunning && !IsCancelling;

        partial void OnCurrentChanged(int value) => RaiseDerived();
        partial void OnTotalChanged(int value) => RaiseDerived();

        partial void OnIsRunningChanged(bool value)
        {
            OnPropertyChanged(nameof(CanCancel));
        }

        partial void OnIsCancellingChanged(bool value)
        {
            OnPropertyChanged(nameof(CanCancel));
        }

        private void RaiseDerived()
        {
            OnPropertyChanged(nameof(Percent));
            OnPropertyChanged(nameof(CounterText));
        }

        /// <summary>Begin a run of <paramref name="total"/> items.</summary>
        public void Begin(int total, string statusText = "Running")
        {
            Total = total;
            Current = 0;
            CurrentItem = string.Empty;
            IsCancelling = false;
            IsRunning = true;
            StatusText = statusText;
        }

        /// <summary>Update the counter. Cheap — safe to call per element.</summary>
        public void Report(int current, string currentItem = null)
        {
            Current = current;
            if (currentItem != null) CurrentItem = currentItem;
        }

        /// <summary>End the run. Leaves Current/Total intact so the footer keeps the final figures.</summary>
        public void End(string statusText)
        {
            IsRunning = false;
            IsCancelling = false;
            CurrentItem = string.Empty;
            StatusText = statusText;
        }

        /// <summary>Called by the Cancel button. The engine picks this up on its next poll.</summary>
        public void RequestCancel()
        {
            if (!IsRunning) return;
            IsCancelling = true;
            StatusText = "Cancelling — rolling back";
        }

        public void Reset()
        {
            IsRunning = false;
            IsCancelling = false;
            Current = 0;
            Total = 0;
            CurrentItem = string.Empty;
            StatusText = "Ready";
        }
    }
}
