using System;
using System.Windows.Interop;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.SpatialDataAssigner.V001.Infrastructure.ExternalEvents;
using Revit26_Plugin.SpatialDataAssigner.V001.UI.ViewModels;
using Revit26_Plugin.SpatialDataAssigner.V001.UI.Views;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Commands
{
    /// <summary>
    /// Ribbon entry point for the Spatial Data Assigner.
    ///
    /// ExternalEvent.Create() is called HERE, inside Execute(), per the suite
    /// convention — creating it at class or static scope binds it to whatever
    /// context happened to load the assembly and fails intermittently.
    ///
    /// The window is modeless (Show, not ShowDialog) and is owned by the Revit
    /// main window so it stays on top of Revit without being always-on-top of
    /// everything else.
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class SpatialDataAssignerCommand : IExternalCommand
    {
        /// <summary>Held so a second ribbon click focuses the open window instead of opening a second one.</summary>
        private static SpatialDataAssignerWindow _window;

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                UIDocument uiDoc = commandData.Application.ActiveUIDocument;

                if (uiDoc?.Document == null)
                {
                    message = "No active document.";
                    return Result.Failed;
                }

                if (uiDoc.Document.IsFamilyDocument)
                {
                    TaskDialog.Show(SpatialDataAssignerViewModel.ToolTitle,
                        "This tool runs in a project document, not the family editor.");
                    return Result.Cancelled;
                }

                // Already open — bring it forward rather than spawning a duplicate.
                if (_window != null && _window.IsLoaded)
                {
                    _window.Activate();
                    return Result.Succeeded;
                }

                var handler = new SpatialDataAssignerHandler();
                ExternalEvent externalEvent = ExternalEvent.Create(handler);

                var vm = new SpatialDataAssignerViewModel(uiDoc, externalEvent, handler);

                _window = new SpatialDataAssignerWindow(vm);
                _window.Closed += (s, e) => _window = null;

                // Owner = the Revit main window, so the tool floats over Revit
                // and minimises with it.
                new WindowInteropHelper(_window)
                {
                    Owner = commandData.Application.MainWindowHandle
                };

                _window.Show();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = $"{ex.GetType().Name}: {ex.Message}";
                return Result.Failed;
            }
        }
    }
}
