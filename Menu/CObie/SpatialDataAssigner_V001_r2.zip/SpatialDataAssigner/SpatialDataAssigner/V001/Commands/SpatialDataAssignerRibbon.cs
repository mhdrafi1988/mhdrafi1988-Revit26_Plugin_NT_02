using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Media.Imaging;
using Autodesk.Revit.UI;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Commands
{
    /// <summary>
    /// Ribbon registration for the Spatial Data Assigner.
    ///
    /// The suite's IExternalApplication (App.cs) calls this once from OnStartup:
    ///
    ///     public Result OnStartup(UIControlledApplication application)
    ///     {
    ///         // ... existing tabs and panels ...
    ///         SpatialDataAssignerRibbon.Register(application);
    ///         return Result.Succeeded;
    ///     }
    ///
    /// Register() is idempotent and self-contained: it creates the tab and panel
    /// only if they do not already exist, so call order against the other tools
    /// does not matter and a second call cannot throw a duplicate-name exception.
    ///
    /// ASSUMPTION (flagged, change the two consts below if wrong):
    ///   Tab   = "Revit26 Plugin"
    ///   Panel = "BIM Handover"
    /// A new panel is used rather than an existing one because this is the first
    /// of the handover tools — Parameter Auditor, COBie Exporter, Classification
    /// Assigner and the rest are intended to land on the same panel.
    /// </summary>
    public static class SpatialDataAssignerRibbon
    {
        public const string TabName = "Revit26 Plugin";
        public const string PanelName = "BIM Handover";

        private const string ButtonName = "btnSpatialDataAssigner";
        private const string ButtonText = "Spatial\nData";

        private const string CommandClass =
            "Revit26_Plugin.SpatialDataAssigner.V001.Commands.SpatialDataAssignerCommand";

        /// <summary>Icon resource names. Missing icons degrade to a text-only button.</summary>
        private const string Icon32 = "Revit26_Plugin.Resources.SpatialDataAssigner_32.png";
        private const string Icon16 = "Revit26_Plugin.Resources.SpatialDataAssigner_16.png";

        /// <summary>
        /// Adds the button to the ribbon. Safe to call more than once.
        /// Never throws — a ribbon failure must not stop Revit from loading the
        /// rest of the suite, so problems are swallowed and reported by return value.
        /// </summary>
        public static bool Register(UIControlledApplication application)
        {
            try
            {
                RibbonPanel panel = GetOrCreatePanel(application, TabName, PanelName);
                if (panel == null) return false;

                // Already added — a second OnStartup (or a reload) must not duplicate it.
                bool exists = panel.GetItems()
                    .OfType<PushButton>()
                    .Any(b => string.Equals(b.Name, ButtonName, StringComparison.Ordinal));

                if (exists) return true;

                string assemblyPath = Assembly.GetExecutingAssembly().Location;

                var data = new PushButtonData(ButtonName, ButtonText, assemblyPath, CommandClass)
                {
                    ToolTip = "Assign level, room, grid and zone data to elements for COBie handover",

                    LongDescription =
                        "Writes 18 spatial parameters to every element inside the chosen scope box:\n\n" +
                        "•  Nearest level below and above, with both offsets measured from the element bottom\n" +
                        "•  Room number, name and level from a linked architectural model, " +
                        "resolved Direct → Above → Below → Nearest in plan\n" +
                        "•  Nearest grid intersection with signed offsets to each grid\n" +
                        "•  Zone, taken from the scope box name\n\n" +
                        "Results are resolved in memory first; a single transaction writes them as one " +
                        "undo step, and Cancel rolls the whole run back so the model is never left " +
                        "partially assigned."
                };

                var button = panel.AddItem(data) as PushButton;
                if (button == null) return false;

                // Icons are optional — the button is usable without them.
                BitmapImage large = LoadEmbeddedIcon(Icon32);
                BitmapImage small = LoadEmbeddedIcon(Icon16);

                if (large != null) button.LargeImage = large;
                if (small != null) button.Image = small;

                return true;
            }
            catch
            {
                // Swallowed deliberately: see the summary above.
                return false;
            }
        }

        /// <summary>
        /// Returns the named panel on the named tab, creating either as needed.
        /// Revit throws if a tab or panel name already exists, so both creations
        /// are probed first rather than guarded by exception handling.
        /// </summary>
        private static RibbonPanel GetOrCreatePanel(
            UIControlledApplication application,
            string tabName,
            string panelName)
        {
            // GetRibbonPanels(tab) throws when the tab does not exist yet,
            // so the tab is created first and the throw is used as the probe.
            try
            {
                RibbonPanel existing = application
                    .GetRibbonPanels(tabName)
                    .FirstOrDefault(p => string.Equals(p.Name, panelName, StringComparison.Ordinal));

                if (existing != null) return existing;

                return application.CreateRibbonPanel(tabName, panelName);
            }
            catch (Autodesk.Revit.Exceptions.InvalidOperationException)
            {
                // Tab does not exist — create it, then the panel.
                application.CreateRibbonTab(tabName);
                return application.CreateRibbonPanel(tabName, panelName);
            }
            catch (Autodesk.Revit.Exceptions.ArgumentException)
            {
                // Tab exists but the panel name collided mid-call; re-query.
                return application
                    .GetRibbonPanels(tabName)
                    .FirstOrDefault(p => string.Equals(p.Name, panelName, StringComparison.Ordinal));
            }
        }

        /// <summary>
        /// Loads a PNG compiled into the assembly as an EmbeddedResource.
        /// Returns null when the resource is absent, so a missing icon is a
        /// cosmetic issue rather than a load failure.
        ///
        /// In the .csproj:
        ///   &lt;ItemGroup&gt;
        ///     &lt;EmbeddedResource Include="Resources\SpatialDataAssigner_32.png" /&gt;
        ///     &lt;EmbeddedResource Include="Resources\SpatialDataAssigner_16.png" /&gt;
        ///   &lt;/ItemGroup&gt;
        /// </summary>
        private static BitmapImage LoadEmbeddedIcon(string resourceName)
        {
            try
            {
                Assembly asm = Assembly.GetExecutingAssembly();

                using (Stream stream = asm.GetManifestResourceStream(resourceName))
                {
                    if (stream == null) return null;

                    var image = new BitmapImage();
                    image.BeginInit();
                    image.StreamSource = stream;
                    // Load fully before the stream closes, or WPF reads a disposed stream.
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.EndInit();
                    image.Freeze();

                    return image;
                }
            }
            catch
            {
                return null;
            }
        }
    }
}
