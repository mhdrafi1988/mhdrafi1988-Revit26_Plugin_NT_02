using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Engine;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Models;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Services;
using Revit26_Plugin.SpatialDataAssigner.V001.Infrastructure.ExternalEvents;
using Revit26_Plugin.SpatialDataAssigner.V001.Infrastructure.Helpers;

namespace Revit26_Plugin.SpatialDataAssigner.V001.UI.ViewModels
{
    /// <summary>
    /// ViewModel for the Spatial Data Assigner window.
    /// Owns the four-stage state, the log, the progress footer and the settings POCO.
    /// All Revit API work is marshalled through the single ExternalEvent.
    /// </summary>
    public partial class SpatialDataAssignerViewModel : ObservableObject
    {
        public const string ToolTitle = "Spatial Data Assigner — V001";

        private readonly UIDocument _uiDoc;
        private readonly Document _doc;
        private readonly ExternalEvent _event;
        private readonly SpatialDataAssignerHandler _handler;

        /// <summary>
        /// Captured here, in the constructor, because Application.Current is
        /// unreliable in Revit's process. The resolve engine needs this to pump the
        /// message queue during a long run — without it Cancel never fires.
        /// </summary>
        private readonly Dispatcher _dispatcher;

        private SdaSettings _settings;

        // Caches rebuilt by Scan, reused by Preview and Run.
        private List<ScopeBoxService.ScopeBoxInfo> _scopeBoxes = new List<ScopeBoxService.ScopeBoxInfo>();
        private List<Element> _inScopeElements = new List<Element>();
        private List<RevitLinkInstance> _linkInstances = new List<RevitLinkInstance>();
        private LevelResolver _levels;
        private GridResolver _grids;

        public SpatialDataAssignerViewModel(
            UIDocument uiDoc,
            ExternalEvent externalEvent,
            SpatialDataAssignerHandler handler)
        {
            _uiDoc = uiDoc;
            _doc = uiDoc.Document;
            _event = externalEvent;
            _handler = handler;
            _dispatcher = Dispatcher.CurrentDispatcher;

            _handler.Work = OnRevitWork;
            _handler.OnError = OnRevitError;

            _settings = SettingsService.Load(out string note);

            Log(LogLevel.Info, $"{ToolTitle} opened");
            Log(LogLevel.Info, note);

            UseViewScopeBox = _settings.UseViewScopeBox;
            RoomSearchRadiusMm = _settings.RoomSearchRadiusMm.ToString("F0");
            SharedParameterFilePath = _settings.SharedParameterFilePath ?? string.Empty;

            ParameterRows = new ObservableCollection<ParameterRow>(
                SdaParameters.All.Select(d => new ParameterRow
                {
                    Name = d.Name,
                    TypeLabel = d.TypeLabel,
                    Required = d.Required,
                    IsBound = false
                }));

            RequestScan();
        }

        // ──────────────────────────────────────────────────────────────
        // Collections
        // ──────────────────────────────────────────────────────────────

        public ObservableCollection<LogEntry> LogEntries { get; } = new ObservableCollection<LogEntry>();
        public ObservableCollection<CategoryRow> CategoryRows { get; } = new ObservableCollection<CategoryRow>();
        public ObservableCollection<LinkRoomRow> LinkRows { get; } = new ObservableCollection<LinkRoomRow>();
        public ObservableCollection<ParameterRow> ParameterRows { get; }
        public ObservableCollection<ResultRow> ResultRows { get; } = new ObservableCollection<ResultRow>();
        public ObservableCollection<ResultRow> UnresolvedRows { get; } = new ObservableCollection<ResultRow>();
        public ObservableCollection<string> ScopeBoxNames { get; } = new ObservableCollection<string>();

        public ProgressState Progress { get; } = new ProgressState();

        /// <summary>Set by the View so Copy Selected knows what the user picked.</summary>
        public IList<LogEntry> SelectedLogEntries { get; set; } = new List<LogEntry>();

        // ──────────────────────────────────────────────────────────────
        // Stage 1 — scope and zone
        // ──────────────────────────────────────────────────────────────

        [ObservableProperty] private string _activeViewName = string.Empty;
        [ObservableProperty] private string _selectedScopeBoxName = string.Empty;
        [ObservableProperty] private bool _useViewScopeBox = true;
        [ObservableProperty] private int _elementsInView;
        [ObservableProperty] private int _elementsInScope;
        [ObservableProperty] private double _scopeBoxRotationDeg;
        [ObservableProperty] private bool _stage1Complete;

        partial void OnSelectedScopeBoxNameChanged(string value)
        {
            if (!string.IsNullOrWhiteSpace(value) && !Progress.IsRunning)
                RequestScan();
        }

        public string ZoneName => string.IsNullOrWhiteSpace(SelectedScopeBoxName)
            ? "(none)"
            : SelectedScopeBoxName;

        // ──────────────────────────────────────────────────────────────
        // Stage 2 — categories
        // ──────────────────────────────────────────────────────────────

        [ObservableProperty] private string _categoryFilter = string.Empty;
        [ObservableProperty] private bool _stage2Complete;

        public IEnumerable<CategoryRow> VisibleCategoryRows =>
            CategoryRows.Where(r => r.MatchesFilter(CategoryFilter));

        partial void OnCategoryFilterChanged(string value)
            => OnPropertyChanged(nameof(VisibleCategoryRows));

        public int SelectedCategoryCount => CategoryRows.Count(r => r.IsSelected);
        public int SelectedElementCount => CategoryRows.Where(r => r.IsSelected).Sum(r => r.InScope);

        public string CategorySummary =>
            $"{SelectedCategoryCount} of {CategoryRows.Count} categories selected · {SelectedElementCount:N0} elements";

        // ──────────────────────────────────────────────────────────────
        // Stage 3 — room source
        // ──────────────────────────────────────────────────────────────

        [ObservableProperty] private string _roomSearchRadiusMm = "3000";
        [ObservableProperty] private bool _stage3Complete;

        public LinkRoomRow SelectedLinkRow => LinkRows.FirstOrDefault(r => r.IsSelected);

        public string RoomSourceName => SelectedLinkRow?.LinkName ?? "(none)";

        // ──────────────────────────────────────────────────────────────
        // Stage 4 — parameters
        // ──────────────────────────────────────────────────────────────

        [ObservableProperty] private string _sharedParameterFilePath = string.Empty;

        public int BoundCount => ParameterRows.Count(p => p.IsBound);
        public int MissingCount => ParameterRows.Count(p => !p.IsBound);
        public int MissingRequiredCount => ParameterRows.Count(p => !p.IsBound && p.Required);

        public string ParamsSummary => $"{BoundCount} / {ParameterRows.Count}";
        public bool Stage4Complete => MissingRequiredCount == 0;

        // ──────────────────────────────────────────────────────────────
        // Metrics card and footer
        // ──────────────────────────────────────────────────────────────

        [ObservableProperty] private int _resolvedCount;
        [ObservableProperty] private int _fallbackCount;
        [ObservableProperty] private int _unresolvedCount;
        [ObservableProperty] private string _summaryLine = string.Empty;
        [ObservableProperty] private bool _hasRun;
        [ObservableProperty] private string _elapsedText = string.Empty;

        public string StatusLabel
        {
            get
            {
                if (Progress.IsRunning) return "Running";
                if (HasRun) return "Completed";
                if (MissingRequiredCount > 0) return $"{MissingRequiredCount} to bind";
                if (!CanRun) return "Not ready";
                return "Ready to run";
            }
        }

        /// <summary>
        /// Run is blocked while an operation is in progress, while required
        /// parameters are unbound, and when any stage is incomplete.
        /// </summary>
        public bool CanRun =>
            !Progress.IsRunning
            && Stage1Complete
            && SelectedCategoryCount > 0
            && SelectedLinkRow != null
            && MissingRequiredCount == 0;

        /// <summary>Stage cards are locked and dimmed during a run.</summary>
        public bool StagesEnabled => !Progress.IsRunning;

        // ──────────────────────────────────────────────────────────────
        // Commands
        // ──────────────────────────────────────────────────────────────

        [RelayCommand]
        private void SelectAllCategories()
        {
            foreach (var r in VisibleCategoryRows.ToList()) r.IsSelected = true;
            RefreshCategoryDerived();
            Log(LogLevel.Info, $"Select All — {SelectedCategoryCount} categories, {SelectedElementCount:N0} elements");
        }

        [RelayCommand]
        private void ClearCategories()
        {
            foreach (var r in VisibleCategoryRows.ToList()) r.IsSelected = false;
            RefreshCategoryDerived();
            Log(LogLevel.Info, "Clear — no categories selected");
        }

        [RelayCommand]
        private void Refresh() => RequestScan();

        [RelayCommand]
        private void BrowseSharedParameterFile()
        {
            var dlg = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Select the shared parameter file",
                Filter = "Shared parameter file (*.txt)|*.txt|All files (*.*)|*.*",
                CheckFileExists = true
            };

            if (dlg.ShowDialog() == true)
            {
                SharedParameterFilePath = dlg.FileName;
                _settings.SharedParameterFilePath = dlg.FileName;
                Log(LogLevel.Info, $"Shared parameter file: {dlg.FileName}");
                RequestScan();
            }
        }

        [RelayCommand]
        private void BindMissing()
        {
            if (MissingCount == 0)
            {
                Log(LogLevel.Info, "Nothing to bind — all parameters present");
                return;
            }

            if (string.IsNullOrWhiteSpace(SharedParameterFilePath))
            {
                Log(LogLevel.Warning, "No shared parameter file selected");
                TaskDialog.Show(ToolTitle, "Select a shared parameter file before binding.");
                return;
            }

            Raise(SdaRequest.BindParameters);
        }

        [RelayCommand]
        private void Preview() => Raise(SdaRequest.Preview);

        [RelayCommand(CanExecute = nameof(CanRun))]
        private void Run() => Raise(SdaRequest.Run);

        [RelayCommand]
        private void Cancel()
        {
            Progress.RequestCancel();
            Log(LogLevel.Warning, "Cancel requested — the run will roll back at its next checkpoint");
            RefreshCommandStates();
        }

        [RelayCommand]
        private void Reset()
        {
            if (Progress.IsRunning) return;

            ResultRows.Clear();
            UnresolvedRows.Clear();
            ResolvedCount = 0;
            FallbackCount = 0;
            UnresolvedCount = 0;
            SummaryLine = string.Empty;
            ElapsedText = string.Empty;
            HasRun = false;
            Progress.Reset();

            Log(LogLevel.Info, "Reset — results cleared, model untouched");
            RequestScan();
        }

        [RelayCommand]
        private void CopyAllLog()
        {
            TrySetClipboard(LogExportService.ToClipboardText(LogEntries), LogEntries.Count);
        }

        [RelayCommand]
        private void CopySelectedLog()
        {
            var sel = SelectedLogEntries?.ToList() ?? new List<LogEntry>();
            if (sel.Count == 0)
            {
                Log(LogLevel.Warning, "No log rows selected");
                return;
            }
            TrySetClipboard(LogExportService.ToClipboardText(sel), sel.Count);
        }

        [RelayCommand]
        private void ClearLog()
        {
            LogEntries.Clear();
            Log(LogLevel.Info, "Log cleared");
        }

        [RelayCommand]
        private void ExportLog()
        {
            string folder = PromptLogFolder();
            if (folder == null) return;

            LogExportService.SaveLog(LogEntries, folder, out string note);
            Log(LogLevel.Info, note);
        }

        [RelayCommand]
        private void ExportUnresolvedCsv()
        {
            if (UnresolvedRows.Count == 0)
            {
                Log(LogLevel.Info, "No unresolved elements to export");
                return;
            }

            string folder = PromptLogFolder();
            if (folder == null) return;

            LogExportService.SaveUnresolvedCsv(UnresolvedRows, folder, out string note);
            Log(LogLevel.Info, note);
        }

        [RelayCommand]
        private void SelectUnresolved()
        {
            if (UnresolvedRows.Count == 0) return;

            try
            {
                var ids = UnresolvedRows
                    .Select(r => new ElementId((long)r.ElementId))
                    .ToList();

                _uiDoc.Selection.SetElementIds(ids);
                Log(LogLevel.Info, $"{ids.Count:N0} unresolved elements selected in the model");
            }
            catch (Exception ex)
            {
                Log(LogLevel.Error, $"Selection failed — {ex.GetType().Name}: {ex.Message}");
            }
        }

        // ──────────────────────────────────────────────────────────────
        // ExternalEvent plumbing
        // ──────────────────────────────────────────────────────────────

        private void RequestScan()
        {
            if (Progress.IsRunning) return;
            Raise(SdaRequest.Scan);
        }

        private void Raise(SdaRequest request)
        {
            _handler.Request = request;
            _event.Raise();
        }

        /// <summary>Runs on the Revit API thread. The only place Revit objects are touched.</summary>
        private void OnRevitWork(UIApplication app, SdaRequest request)
        {
            switch (request)
            {
                case SdaRequest.Scan: DoScan(); break;
                case SdaRequest.BindParameters: DoBind(app); break;
                case SdaRequest.Preview: DoRun(previewOnly: true); break;
                case SdaRequest.Run: DoRun(previewOnly: false); break;
            }

            RefreshAllDerived();
        }

        private void OnRevitError(Exception ex)
        {
            Log(LogLevel.Error, $"{ex.GetType().Name}: {ex.Message}");
            Progress.End("Failed");

            TaskDialog.Show(ToolTitle,
                $"The operation failed and the model was left unchanged.\n\n{ex.Message}");

            RefreshAllDerived();
        }

        // ──────────────────────────────────────────────────────────────
        // Revit-side work
        // ──────────────────────────────────────────────────────────────

        private void DoScan()
        {
            View view = _doc.ActiveView;
            ActiveViewName = view?.Name ?? "(none)";
            Log(LogLevel.Info, $"Active view: {ActiveViewName}");

            // ── Scope boxes ──────────────────────────────────────────
            _scopeBoxes = ScopeBoxService.Collect(_doc);
            ScopeBoxNames.Clear();
            foreach (var b in _scopeBoxes) ScopeBoxNames.Add(b.Name);

            ScopeBoxService.ScopeBoxInfo active = null;

            if (UseViewScopeBox)
            {
                active = ScopeBoxService.FromView(_doc, view);
                if (active != null)
                {
                    SelectedScopeBoxName = active.Name;
                    Log(LogLevel.Success, $"Scope box on view: {active.Name}");
                }
            }

            if (active == null && !string.IsNullOrWhiteSpace(SelectedScopeBoxName))
                active = _scopeBoxes.FirstOrDefault(b =>
                    string.Equals(b.Name, SelectedScopeBoxName, StringComparison.OrdinalIgnoreCase));

            if (active == null && !string.IsNullOrWhiteSpace(_settings.LastScopeBoxName))
            {
                active = _scopeBoxes.FirstOrDefault(b =>
                    string.Equals(b.Name, _settings.LastScopeBoxName, StringComparison.OrdinalIgnoreCase));
                if (active != null) SelectedScopeBoxName = active.Name;
            }

            if (active == null)
            {
                Stage1Complete = false;
                Log(LogLevel.Warning, "No scope box assigned to the view — pick one to set the zone");
                return;
            }

            ScopeBoxRotationDeg = active.RotationDeg;
            if (Math.Abs(active.RotationDeg) > 0.05)
                Log(LogLevel.Info, $"Scope box transform: rotated {active.RotationDeg:F1}° about Z");

            // ── Elements in view, bucketed by category ───────────────
            var viewElements = new FilteredElementCollector(_doc, view.Id)
                .WhereElementIsNotElementType()
                .Where(e => e.Category != null && e.Category.CategoryType == CategoryType.Model)
                .ToList();

            ElementsInView = viewElements.Count;
            Log(LogLevel.Info, $"Collected {ElementsInView:N0} elements in view");

            var previouslySelected = CategoryRows.Count > 0
                ? CategoryRows.Where(r => r.IsSelected).Select(r => r.Name).ToHashSet()
                : new HashSet<string>(_settings.SelectedCategoryNames ?? new List<string>());

            var byCategory = viewElements
                .GroupBy(e => e.Category.Id.Value)
                .ToList();

            CategoryRows.Clear();
            _inScopeElements.Clear();

            foreach (var group in byCategory.OrderBy(g => _doc.Settings.Categories
                         .Cast<Category>().FirstOrDefault(c => c.Id.Value == g.Key)?.Name ?? ""))
            {
                var sample = group.First();
                string catName = sample.Category.Name;

                var inScope = group
                    .Where(e =>
                    {
                        var a = AnchorService.Resolve(e);
                        return a.IsValid && ScopeBoxService.Contains(active, a.Point);
                    })
                    .ToList();

                var row = new CategoryRow
                {
                    Name = catName,
                    CategoryId = (int)group.Key,
                    InView = group.Count(),
                    InScope = inScope.Count,
                    IsSelected = previouslySelected.Contains(catName)
                };

                row.PropertyChanged += (s, e) =>
                {
                    if (e.PropertyName == nameof(CategoryRow.IsSelected)) RefreshCategoryDerived();
                };

                CategoryRows.Add(row);
            }

            ElementsInScope = CategoryRows.Sum(r => r.InScope);
            Log(LogLevel.Info,
                $"Containment test: {ElementsInScope:N0} inside / {ElementsInView - ElementsInScope:N0} outside");

            Stage1Complete = true;

            // ── Levels and grids ─────────────────────────────────────
            _levels = new LevelResolver(_doc);
            Log(LogLevel.Info,
                $"Levels cached: {_levels.Levels.Count:N0} " +
                $"({UnitFormat.FtToMm(_levels.MinElevation) / 1000d:F3} m to {UnitFormat.FtToMm(_levels.MaxElevation) / 1000d:F3} m)");

            if (_levels.TiedLevelNames.Count > 0)
                Log(LogLevel.Warning,
                    $"{_levels.TiedLevelNames.Count} levels share an elevation — lowest name used for ties");

            _grids = new GridResolver(_doc, _settings.GridPairMinAngleDeg);
            Log(LogLevel.Info,
                $"Grid curves cached: {_grids.GridCount:N0} ({_grids.ArcGridCount} radial, {_grids.LineGridCount} orthogonal)");

            if (_grids.ArcGridCount > 0)
                Log(LogLevel.Warning, "Radial grids present — nearest transverse-pair fallback enabled");

            // ── Linked models with rooms ─────────────────────────────
            ScanLinks();

            // ── Parameter bindings ───────────────────────────────────
            ScanParameters();
        }

        private void ScanLinks()
        {
            string previous = SelectedLinkRow?.LinkName ?? _settings.LastRoomLinkName;

            _linkInstances = new FilteredElementCollector(_doc)
                .OfClass(typeof(RevitLinkInstance))
                .Cast<RevitLinkInstance>()
                .ToList();

            LinkRows.Clear();
            Log(LogLevel.Info, $"Scanning {_linkInstances.Count} linked models for rooms");

            foreach (var li in _linkInstances)
            {
                Document linkDoc = li.GetLinkDocument();
                if (linkDoc == null)
                {
                    Log(LogLevel.Warning, $"{li.Name} — not loaded, skipped");
                    continue;
                }

                var rooms = new FilteredElementCollector(linkDoc)
                    .OfCategory(BuiltInCategory.OST_Rooms)
                    .WhereElementIsNotElementType()
                    .ToElements();

                int named = rooms.Count(r => !string.IsNullOrWhiteSpace(r.Name));

                var row = new LinkRoomRow
                {
                    LinkName = linkDoc.Title,
                    LinkInstanceId = (int)li.Id.Value,
                    RoomCount = rooms.Count,
                    NamedCount = named
                };

                if (row.RoomCount == 0)
                    Log(LogLevel.Warning, $"{row.LinkName} — no rooms, skipped");
                else
                    Log(LogLevel.Info, $"{row.LinkName} — {row.RoomCount:N0} rooms, {named:N0} named");

                if (row.RoomCount > 0 && named < row.RoomCount)
                    Log(LogLevel.Warning, $"{row.LinkName} — {row.RoomCount - named:N0} rooms unnamed");

                row.PropertyChanged += (s, e) =>
                {
                    if (e.PropertyName == nameof(LinkRoomRow.IsSelected)) RefreshAllDerived();
                };

                LinkRows.Add(row);
            }

            // Host model, in case rooms live here rather than in a link.
            var hostRooms = new FilteredElementCollector(_doc)
                .OfCategory(BuiltInCategory.OST_Rooms)
                .WhereElementIsNotElementType()
                .ToElements();

            var hostRow = new LinkRoomRow
            {
                LinkName = $"{_doc.Title} (host)",
                LinkInstanceId = -1,
                RoomCount = hostRooms.Count,
                NamedCount = hostRooms.Count(r => !string.IsNullOrWhiteSpace(r.Name))
            };
            hostRow.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(LinkRoomRow.IsSelected)) RefreshAllDerived();
            };
            LinkRows.Add(hostRow);

            var restore = LinkRows.FirstOrDefault(r =>
                r.IsUsable && string.Equals(r.LinkName, previous, StringComparison.OrdinalIgnoreCase))
                ?? LinkRows.FirstOrDefault(r => r.IsUsable);

            if (restore != null)
            {
                SetLinkSelection(restore);
                Log(LogLevel.Success, $"Room source set: {restore.LinkName}");
                Stage3Complete = true;
            }
            else
            {
                Stage3Complete = false;
                Log(LogLevel.Warning, "No link carries usable rooms — room values cannot be assigned");
            }
        }

        /// <summary>Radio semantics — the grid is single-select by VM property, not by DataGrid selection.</summary>
        public void SetLinkSelection(LinkRoomRow row)
        {
            foreach (var r in LinkRows) r.IsSelected = ReferenceEquals(r, row);
            RefreshAllDerived();
        }

        private void ScanParameters()
        {
            var cats = SelectedCategories();
            if (cats.Count == 0)
            {
                foreach (var p in ParameterRows) p.IsBound = false;
                Log(LogLevel.Info, "No categories selected — parameter check skipped");
                return;
            }

            var rows = ParameterBindingService.CheckBindings(_doc, cats);

            foreach (var r in rows)
            {
                var existing = ParameterRows.FirstOrDefault(p => p.Name == r.Name);
                if (existing != null) existing.IsBound = r.IsBound;
            }

            Log(LogLevel.Info, $"Parameter check across {cats.Count} categories");
            Log(MissingCount == 0 ? LogLevel.Success : LogLevel.Warning,
                $"{BoundCount} of {ParameterRows.Count} bound");

            foreach (var missing in ParameterRows.Where(p => !p.IsBound))
                Log(LogLevel.Warning, $"{missing.Name} not bound");
        }

        private void DoBind(UIApplication app)
        {
            var cats = SelectedCategories();
            var missing = ParameterRows.Where(p => !p.IsBound).Select(p => p.Name).ToList();

            using (var tx = new Transaction(_doc, "SDA Bind Parameters"))
            {
                try
                {
                    tx.Start();

                    var result = ParameterBindingService.BindMissing(
                        _doc, app.Application, SharedParameterFilePath, cats, missing);

                    if (!result.Success)
                    {
                        tx.RollBack();
                        Log(LogLevel.Error, $"Binding failed — rolled back. {result.Error}");
                        TaskDialog.Show(ToolTitle, $"Parameters were not bound.\n\n{result.Error}");
                        return;
                    }

                    tx.Commit();

                    Log(LogLevel.Success, $"{result.BoundCount} parameters bound");
                    foreach (var n in result.NotInFile)
                        Log(LogLevel.Warning, $"{n} not found in the shared parameter file");
                }
                catch (Exception ex)
                {
                    if (tx.HasStarted() && !tx.HasEnded()) tx.RollBack();
                    Log(LogLevel.Error, $"Binding failed — rolled back. {ex.GetType().Name}: {ex.Message}");
                    TaskDialog.Show(ToolTitle, $"Parameters were not bound.\n\n{ex.Message}");
                    return;
                }
            }

            ScanParameters();
        }

        private void DoRun(bool previewOnly)
        {
            var box = _scopeBoxes.FirstOrDefault(b =>
                string.Equals(b.Name, SelectedScopeBoxName, StringComparison.OrdinalIgnoreCase));

            if (box == null)
            {
                Log(LogLevel.Error, "No scope box resolved — run aborted");
                return;
            }

            var linkRow = SelectedLinkRow;
            if (linkRow == null)
            {
                Log(LogLevel.Error, "No room source selected — run aborted");
                return;
            }

            // Rebuild the in-scope element list for the selected categories only.
            var selectedCatIds = CategoryRows.Where(r => r.IsSelected)
                .Select(r => (long)r.CategoryId)
                .ToHashSet();

            View view = _doc.ActiveView;

            _inScopeElements = new FilteredElementCollector(_doc, view.Id)
                .WhereElementIsNotElementType()
                .Where(e => e.Category != null && selectedCatIds.Contains(e.Category.Id.Value))
                .Where(e =>
                {
                    var a = AnchorService.Resolve(e);
                    return a.IsValid && ScopeBoxService.Contains(box, a.Point);
                })
                .ToList();

            Log(LogLevel.Info,
                previewOnly
                    ? $"PREVIEW start — first 50 of {_inScopeElements.Count:N0}"
                    : $"RUN start — {_inScopeElements.Count:N0} elements, {SelectedCategoryCount} categories");
            Log(LogLevel.Info, $"Zone = {box.Name} for all in-scope elements");

            // Room resolver, built once per run.
            RoomResolver rooms;
            if (linkRow.LinkInstanceId < 0)
            {
                rooms = new RoomResolver(_doc, Transform.Identity,
                    UnitFormat.MmToFt(_settings.RoomProbeStepMm),
                    UnitFormat.MmToFt(_settings.RoomProbeStepMm * 10),
                    UnitFormat.MmToFt(ParsedRadiusMm()));
            }
            else
            {
                var li = _linkInstances.FirstOrDefault(l => l.Id.Value == linkRow.LinkInstanceId);
                Document linkDoc = li?.GetLinkDocument();

                if (linkDoc == null)
                {
                    Log(LogLevel.Error, "Room source link is no longer loaded — run aborted");
                    return;
                }

                rooms = new RoomResolver(linkDoc, li.GetTotalTransform(),
                    UnitFormat.MmToFt(_settings.RoomProbeStepMm),
                    UnitFormat.MmToFt(_settings.RoomProbeStepMm * 10),
                    UnitFormat.MmToFt(ParsedRadiusMm()));

                Log(LogLevel.Info, "Link transform inverse cached");
            }

            if (rooms.UnplacedRoomCount > 0)
                Log(LogLevel.Warning, $"{rooms.UnplacedRoomCount:N0} rooms unplaced in the source — not indexed");

            Log(LogLevel.Info, "Fallback: Direct > Above > Below > Nearest in plan");
            Log(LogLevel.Info, $"Radius cap: {ParsedRadiusMm():N0} mm");

            var opts = new SpatialResolveEngine.RunOptions
            {
                Elements = _inScopeElements,
                ScopeBox = box,
                ZoneName = box.Name,
                Levels = _levels,
                Grids = _grids,
                Rooms = rooms,
                PreviewLimit = previewOnly ? 50 : 0
            };

            var engine = new SpatialResolveEngine(_doc, Progress, Log, _dispatcher);
            var outcome = engine.Resolve(opts);

            if (!previewOnly && !outcome.Cancelled)
                engine.Write(opts, outcome);

            PublishOutcome(outcome, previewOnly);
        }

        private void PublishOutcome(SpatialResolveEngine.RunOutcome outcome, bool previewOnly)
        {
            ResultRows.Clear();
            UnresolvedRows.Clear();

            foreach (var r in outcome.Rows.Take(500)) ResultRows.Add(r);
            foreach (var r in outcome.Rows.Where(x => x.Status == ResolveStatus.NotFound))
                UnresolvedRows.Add(r);

            ResolvedCount = outcome.Assigned;
            FallbackCount = outcome.Fallback;
            UnresolvedCount = outcome.Unresolved;
            ElapsedText = $"{(int)outcome.Elapsed.TotalMinutes} m {outcome.Elapsed.Seconds} s";

            if (outcome.Cancelled)
            {
                Progress.End("Cancelled — rolled back");
                SummaryLine = "Cancelled — model unchanged";
                Log(LogLevel.Warning, "Run cancelled — TransactionGroup rolled back, model unchanged");
                return;
            }

            if (outcome.Error != null)
            {
                Progress.End("Failed — rolled back");
                SummaryLine = "Failed — model unchanged";
                TaskDialog.Show(ToolTitle,
                    $"The write failed and the model was rolled back.\n\n{outcome.Error}");
                return;
            }

            SummaryLine = outcome.SummaryLine;

            // Unresolved reasons, grouped — far more useful than 58 individual lines.
            var grouped = outcome.Rows
                .Where(r => r.Status == ResolveStatus.NotFound)
                .GroupBy(r => r.Reason)
                .OrderByDescending(g => g.Count());

            foreach (var g in grouped)
                Log(LogLevel.Warning, $"  {g.Count(),5:N0} {g.Key}");

            if (previewOnly)
            {
                Progress.End("Preview complete");
                Log(LogLevel.Success, $"Preview — {outcome.SummaryLine}");
                return;
            }

            HasRun = true;
            Progress.End("Completed");
            Log(LogLevel.Success, outcome.SummaryLine);
            Log(LogLevel.Info, $"Elapsed {ElapsedText}");

            // Auto-save the log. No dialog — suite convention.
            LogExportService.SaveLog(LogEntries, AutoSaveFolder, out string note);
            Log(LogLevel.Success, note);

            SaveSettings();
            Log(LogLevel.Info, "Window stays open — review results or run again");
        }

        // ──────────────────────────────────────────────────────────────
        // Helpers
        // ──────────────────────────────────────────────────────────────

        private List<BuiltInCategory> SelectedCategories()
            => CategoryRows.Where(r => r.IsSelected)
                           .Select(r => (BuiltInCategory)r.CategoryId)
                           .ToList();

        private double ParsedRadiusMm()
            => double.TryParse(RoomSearchRadiusMm, out double mm) && mm > 0 ? mm : 3000d;

        /// <summary>
        /// Folder used by the AUTO-SAVE on completion. Never shows a dialog:
        /// the last folder the user chose for a manual export, else the suite
        /// default under My Documents.
        /// </summary>
        private string AutoSaveFolder =>
            string.IsNullOrWhiteSpace(_settings.LogFolder)
                ? LogExportService.DefaultLogFolder
                : _settings.LogFolder;

        /// <summary>
        /// Folder for a MANUAL export. Prompts once per session, then reuses the
        /// chosen folder for the rest of it.
        /// </summary>
        private string PromptLogFolder()
        {
            if (!string.IsNullOrWhiteSpace(_settings.LogFolder)) return _settings.LogFolder;

            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Title = "Choose where this session's exports are saved",
                FileName = LogExportService.BuildLogFileName(),
                InitialDirectory = LogExportService.DefaultLogFolder,
                Filter = "Text file (*.txt)|*.txt"
            };

            if (dlg.ShowDialog() != true)
            {
                Log(LogLevel.Warning, "No folder chosen — nothing exported");
                return null;
            }

            _settings.LogFolder = System.IO.Path.GetDirectoryName(dlg.FileName);
            Log(LogLevel.Info, $"Export folder for this session: {_settings.LogFolder}");
            return _settings.LogFolder;
        }

        private void TrySetClipboard(string text, int count)
        {
            try
            {
                Clipboard.SetText(text);
                Log(LogLevel.Info, $"{count:N0} log rows copied");
            }
            catch (Exception ex)
            {
                // Clipboard is owned by another process surprisingly often in Revit.
                Log(LogLevel.Error, $"Clipboard unavailable — {ex.GetType().Name}");
            }
        }

        public void SaveSettings()
        {
            _settings.UseViewScopeBox = UseViewScopeBox;
            _settings.LastScopeBoxName = SelectedScopeBoxName;
            _settings.SelectedCategoryNames = CategoryRows.Where(r => r.IsSelected).Select(r => r.Name).ToList();
            _settings.LastRoomLinkName = SelectedLinkRow?.LinkName;
            _settings.RoomSearchRadiusMm = ParsedRadiusMm();
            _settings.SharedParameterFilePath = SharedParameterFilePath;

            SettingsService.Save(_settings, out string note);
            Log(LogLevel.Info, note);
        }

        private void RefreshCategoryDerived()
        {
            OnPropertyChanged(nameof(SelectedCategoryCount));
            OnPropertyChanged(nameof(SelectedElementCount));
            OnPropertyChanged(nameof(CategorySummary));
            Stage2Complete = SelectedCategoryCount > 0;
            RefreshCommandStates();
        }

        private void RefreshAllDerived()
        {
            OnPropertyChanged(nameof(ZoneName));
            OnPropertyChanged(nameof(VisibleCategoryRows));
            OnPropertyChanged(nameof(SelectedCategoryCount));
            OnPropertyChanged(nameof(SelectedElementCount));
            OnPropertyChanged(nameof(CategorySummary));
            OnPropertyChanged(nameof(RoomSourceName));
            OnPropertyChanged(nameof(BoundCount));
            OnPropertyChanged(nameof(MissingCount));
            OnPropertyChanged(nameof(MissingRequiredCount));
            OnPropertyChanged(nameof(ParamsSummary));
            OnPropertyChanged(nameof(Stage4Complete));
            OnPropertyChanged(nameof(StatusLabel));
            OnPropertyChanged(nameof(StagesEnabled));
            RefreshCommandStates();
        }

        private void RefreshCommandStates()
        {
            OnPropertyChanged(nameof(CanRun));
            OnPropertyChanged(nameof(StagesEnabled));
            OnPropertyChanged(nameof(StatusLabel));
            RunCommand.NotifyCanExecuteChanged();
        }

        /// <summary>Appends a log row. Null and blank messages are dropped.</summary>
        private void Log(LogLevel level, string message)
        {
            if (string.IsNullOrWhiteSpace(message)) return;
            LogEntries.Add(new LogEntry(level, message));
        }
    }
}
