using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Models;
using Revit26_Plugin.SpatialDataAssigner.V001.UI.ViewModels;

namespace Revit26_Plugin.SpatialDataAssigner.V001.UI.Views
{
    /// <summary>
    /// Modeless window for the Spatial Data Assigner.
    ///
    /// Code-behind is limited to things that genuinely belong to the View:
    ///   - blocking the checkbox-to-row-selection cascade in the DataGrids
    ///   - radio semantics for the single-select Room Source grid
    ///   - auto-scrolling the log to the newest entry
    ///   - Esc = Close, and refusing to close mid-run
    /// Everything else lives in the ViewModel.
    /// </summary>
    public partial class SpatialDataAssignerWindow : Window
    {
        private readonly SpatialDataAssignerViewModel _vm;

        public SpatialDataAssignerWindow(SpatialDataAssignerViewModel vm)
        {
            InitializeComponent();

            _vm = vm;
            DataContext = _vm;

            // Auto-scroll the log so the newest line is always visible.
            ((INotifyCollectionChanged)_vm.LogEntries).CollectionChanged += (s, e) =>
            {
                if (e.Action != NotifyCollectionChangedAction.Add) return;
                if (LogList.Items.Count == 0) return;

                LogList.ScrollIntoView(LogList.Items[LogList.Items.Count - 1]);
            };

            LogList.SelectionChanged += (s, e) =>
                _vm.SelectedLogEntries = LogList.SelectedItems.Cast<LogEntry>().ToList();

            // Checkbox / radio columns must not drag row selection along with them.
            CategoryGrid.PreviewMouseLeftButtonDown += Grid_PreviewMouseLeftButtonDown;
            LinkGrid.PreviewMouseLeftButtonDown += LinkGrid_PreviewMouseLeftButtonDown;

            PreviewKeyDown += Window_PreviewKeyDown;
            Closing += Window_Closing;
            SourceInitialized += Window_SourceInitialized;
        }

        /// <summary>
        /// UI standard v1.1: the window may grow to default + 30% and no further,
        /// capped to the screen. MaxWidth/MaxHeight in XAML set the 130% ceiling
        /// (1456 x 1144); this clamps it down again on a smaller display, where
        /// 130% would push the footer off-screen.
        ///
        /// The Maximize button is deliberately kept — with MaxWidth/MaxHeight set,
        /// maximising expands to the 130% size rather than filling the screen.
        /// </summary>
        private void Window_SourceInitialized(object sender, System.EventArgs e)
        {
            var area = SystemParameters.WorkArea;

            if (MaxWidth > area.Width) MaxWidth = area.Width;
            if (MaxHeight > area.Height) MaxHeight = area.Height;

            // A min larger than the screen would make the window unusable on a
            // laptop panel, so the floor yields before the ceiling does.
            if (MinWidth > area.Width) MinWidth = area.Width;
            if (MinHeight > area.Height) MinHeight = area.Height;
        }

        /// <summary>
        /// Swallows the row-select that WPF would otherwise raise when the click
        /// lands on the checkbox column, so ticking a box leaves the selection alone.
        /// </summary>
        private void Grid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (FindAncestor<CheckBox>(e.OriginalSource as DependencyObject) == null) return;

            var cell = FindAncestor<DataGridCell>(e.OriginalSource as DependencyObject);
            if (cell == null) return;

            // Let the CheckBox handle its own toggle; stop the bubble to DataGridRow.
            e.Handled = false;
            cell.Focus();
        }

        /// <summary>
        /// Room Source is single-select by ViewModel property, not by DataGrid
        /// selection, so a radio click routes through SetLinkSelection to clear
        /// the other rows.
        /// </summary>
        private void LinkGrid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var radio = FindAncestor<RadioButton>(e.OriginalSource as DependencyObject);
            if (radio == null) return;

            if (radio.DataContext is LinkRoomRow row && row.IsUsable)
                _vm.SetLinkSelection(row);
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Escape) return;

            // Esc closes — but never while a transaction is in flight.
            if (_vm.Progress.IsRunning) return;

            e.Handled = true;
            Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e) => Close();

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (_vm.Progress.IsRunning)
            {
                // The window never auto-closes, and it never closes under a live
                // transaction either — the group would be orphaned.
                e.Cancel = true;
                return;
            }

            _vm.SaveSettings();
        }

        private static T FindAncestor<T>(DependencyObject current) where T : DependencyObject
        {
            while (current != null)
            {
                if (current is T match) return match;
                current = System.Windows.Media.VisualTreeHelper.GetParent(current);
            }
            return null;
        }
    }
}
