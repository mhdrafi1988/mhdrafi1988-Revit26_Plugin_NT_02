using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Threading;
using Autodesk.Revit.DB;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Models;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Services;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Engine
{
    /// <summary>
    /// The resolve + write engine. Runs entirely on the Revit API thread inside
    /// the ExternalEvent handler.
    ///
    /// WHY THE DISPATCHER PUMP
    /// Revit executes external events on the same thread that owns the WPF window.
    /// A tight loop over 8,900 elements therefore freezes the window: no repaint,
    /// and the Cancel button never receives its click, so cancellation could never
    /// fire. Every PumpInterval elements we yield to the dispatcher at Background
    /// priority, which drains pending input and render work. This is the standard
    /// workaround for long synchronous Revit operations with a live UI — it is not
    /// multithreading, and no Revit API object ever leaves this thread.
    ///
    /// TRANSACTION SHAPE (Autodesk-standard, as specified)
    ///   TransactionGroup
    ///     └── Transaction        one, wrapping the whole write loop
    ///   Assimilate() on success  → one undo step named for the tool
    ///   RollBack() on cancel or error → nothing partial reaches the model
    /// Resolution happens first, in memory. The transaction opens only once every
    /// element has a value, so a cancel during the long phase costs nothing.
    /// </summary>
    public class SpatialResolveEngine
    {
        /// <summary>Elements between dispatcher pumps. Low enough to feel responsive, high enough not to crawl.</summary>
        private const int PumpInterval = 40;

        /// <summary>Elements between progress reports. The UI cannot use finer granularity.</summary>
        private const int ReportInterval = 10;

        private readonly Document _doc;
        private readonly ProgressState _progress;
        private readonly Action<LogLevel, string> _log;
        private readonly Dispatcher _dispatcher;

        /// <param name="dispatcher">
        /// The UI dispatcher, captured as Dispatcher.CurrentDispatcher in the
        /// ViewModel constructor. Application.Current is NOT used here —
        /// Application.Current is unreliable in Revit's process (there is often no
        /// WPF Application object at all), which would silently return null and
        /// disable the pump, and with it cancellation.
        /// </param>
        public SpatialResolveEngine(
            Document doc,
            ProgressState progress,
            Action<LogLevel, string> log,
            Dispatcher dispatcher)
        {
            _doc = doc;
            _progress = progress;
            _log = log ?? ((l, m) => { });
            _dispatcher = dispatcher;
        }

        public class RunOptions
        {
            public List<Element> Elements { get; set; } = new List<Element>();
            public ScopeBoxService.ScopeBoxInfo ScopeBox { get; set; }
            public string ZoneName { get; set; }
            public LevelResolver Levels { get; set; }
            public GridResolver Grids { get; set; }
            public RoomResolver Rooms { get; set; }
            public double GridMaxDistanceFt { get; set; } = 500d;
            /// <summary>Preview mode stops after this many elements and never writes.</summary>
            public int PreviewLimit { get; set; } = 0;
        }

        public class RunOutcome
        {
            public List<ResultRow> Rows { get; } = new List<ResultRow>();
            public int Assigned { get; set; }
            public int Fallback { get; set; }
            public int Unresolved { get; set; }
            public int Failed { get; set; }
            public bool Cancelled { get; set; }
            public bool Committed { get; set; }
            public string Error { get; set; }
            public TimeSpan Elapsed { get; set; }

            public string SummaryLine =>
                $"{Assigned:N0} assigned | {Fallback:N0} fallback | {Unresolved:N0} unresolved | {Failed:N0} failed";
        }

        // ──────────────────────────────────────────────────────────────────
        // PHASE 1 — resolve in memory
        // ──────────────────────────────────────────────────────────────────

        public RunOutcome Resolve(RunOptions opts)
        {
            var started = DateTime.Now;
            var outcome = new RunOutcome();

            int total = opts.PreviewLimit > 0
                ? Math.Min(opts.PreviewLimit, opts.Elements.Count)
                : opts.Elements.Count;

            _log(LogLevel.Info, $"STEP 1 Resolve — {total:N0} elements queued");
            _progress.Begin(total, opts.PreviewLimit > 0 ? "Preview" : "Resolving");

            int curveAnchors = 0;
            int noLevelAbove = 0;

            for (int i = 0; i < total; i++)
            {
                if (_progress.IsCancelling)
                {
                    outcome.Cancelled = true;
                    _log(LogLevel.Warning, $"Cancel requested at {i:N0} / {total:N0} — nothing written");
                    break;
                }

                Element el = opts.Elements[i];
                ResultRow row;

                try
                {
                    row = ResolveOne(el, opts, ref curveAnchors, ref noLevelAbove);
                }
                catch (Exception ex)
                {
                    // One bad element must never abort a run of thousands.
                    row = new ResultRow
                    {
                        ElementId = (int)el.Id.Value,
                        Category = el.Category?.Name ?? "(none)",
                        Status = ResolveStatus.NotFound,
                        Reason = $"{ex.GetType().Name}"
                    };
                    outcome.Failed++;
                    _log(LogLevel.Error, $"Id {el.Id.Value} resolve failed — {ex.GetType().Name}: {ex.Message}");
                }

                outcome.Rows.Add(row);

                switch (row.Status)
                {
                    case ResolveStatus.Ok: outcome.Assigned++; break;
                    case ResolveStatus.Fallback: outcome.Fallback++; outcome.Assigned++; break;
                    case ResolveStatus.NotFound: outcome.Unresolved++; break;
                }

                if (i % ReportInterval == 0)
                    _progress.Report(i + 1, $"{row.Category} · Id {row.ElementId}");

                if (i % PumpInterval == 0)
                    Pump();
            }

            _progress.Report(outcome.Rows.Count);

            if (curveAnchors > 0)
                _log(LogLevel.Warning, $"{curveAnchors:N0} curve elements — midpoint anchor used");
            if (noLevelAbove > 0)
                _log(LogLevel.Warning, $"{noLevelAbove:N0} elements above the topmost level — Level Above empty");

            outcome.Elapsed = DateTime.Now - started;
            return outcome;
        }

        private ResultRow ResolveOne(
            Element el,
            RunOptions opts,
            ref int curveAnchors,
            ref int noLevelAbove)
        {
            var row = new ResultRow
            {
                ElementId = (int)el.Id.Value,
                Category = el.Category?.Name ?? "(none)",
                ZoneName = opts.ZoneName
            };

            bool usedFallback = false;

            // ── Anchor ───────────────────────────────────────────────
            var anchor = AnchorService.Resolve(el);
            if (!anchor.IsValid)
            {
                row.Status = ResolveStatus.NotFound;
                row.Reason = anchor.FailureReason;
                return row;
            }
            if (anchor.FromCurve) curveAnchors++;

            row.BottomElevFt = anchor.BottomZ;
            row.TopElevFt = anchor.TopZ;

            // ── Levels — both offsets measured from the element BOTTOM ──
            opts.Levels.Resolve(anchor.BottomZ, out var below, out var above);

            if (below == null)
            {
                row.Status = ResolveStatus.NotFound;
                row.Reason = "No level below";
                return row;
            }

            row.LevelBelow = below.Name;
            row.OffsetFromBelowFt = anchor.BottomZ - below.Elevation;

            if (above == null)
            {
                noLevelAbove++;
                row.LevelAbove = string.Empty;
                row.OffsetToAboveFt = 0d;
                row.Reason = "No level above";
                usedFallback = true;
            }
            else
            {
                row.LevelAbove = above.Name;
                row.OffsetToAboveFt = above.Elevation - anchor.BottomZ;
            }

            // ── Room ─────────────────────────────────────────────────
            var roomHit = opts.Rooms?.Resolve(anchor.Point);
            if (roomHit == null || !roomHit.Resolved)
            {
                row.RoomSource = RoomSource.None;
                row.Status = ResolveStatus.NotFound;
                row.Reason = roomHit?.FailureReason ?? "No room source";
                return row;
            }

            row.RoomNumber = roomHit.Number;
            row.RoomName = roomHit.Name;
            row.RoomLevel = roomHit.LevelName;
            row.RoomSource = roomHit.Source;
            if (roomHit.Source != RoomSource.Direct) usedFallback = true;

            // ── Grid ─────────────────────────────────────────────────
            var gridHit = opts.Grids.Resolve(anchor.Point, opts.GridMaxDistanceFt);
            if (!gridHit.Resolved)
            {
                row.Status = ResolveStatus.NotFound;
                row.Reason = gridHit.FailureReason;
                return row;
            }

            row.GridX = gridHit.NameA;
            row.GridY = gridHit.NameB;
            row.GridOffsetXFt = gridHit.OffsetAFt;
            row.GridOffsetYFt = gridHit.OffsetBFt;

            row.Status = usedFallback ? ResolveStatus.Fallback : ResolveStatus.Ok;
            return row;
        }

        // ──────────────────────────────────────────────────────────────────
        // PHASE 2 — write, inside one Transaction inside one TransactionGroup
        // ──────────────────────────────────────────────────────────────────

        public void Write(RunOptions opts, RunOutcome outcome)
        {
            if (outcome.Cancelled) return;

            string stamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
            _progress.Begin(outcome.Rows.Count, "Writing parameters");
            _log(LogLevel.Info, "Resolution complete — opening TransactionGroup");

            using (var group = new TransactionGroup(_doc, "SDA Assign V001"))
            {
                group.Start();

                using (var tx = new Transaction(_doc, "SDA Write Parameters"))
                {
                    try
                    {
                        tx.Start();
                        _log(LogLevel.Info, "Transaction: SDA Write Parameters");

                        int written = 0;

                        for (int i = 0; i < outcome.Rows.Count; i++)
                        {
                            if (_progress.IsCancelling)
                            {
                                tx.RollBack();
                                group.RollBack();
                                outcome.Cancelled = true;
                                outcome.Committed = false;
                                _log(LogLevel.Warning, "Cancelled during write — transaction rolled back, model unchanged");
                                _progress.End("Cancelled — rolled back");
                                return;
                            }

                            ResultRow row = outcome.Rows[i];
                            Element el = opts.Elements[i];

                            WriteRow(el, row, stamp);
                            written++;

                            if (i % ReportInterval == 0)
                                _progress.Report(i + 1, $"Id {row.ElementId}");
                            if (i % PumpInterval == 0)
                                Pump();
                        }

                        _log(LogLevel.Info,
                            $"{SdaParameters.All.Count} params x {written:N0} elements = {SdaParameters.All.Count * written:N0} writes");

                        tx.Commit();
                        _log(LogLevel.Success, "Transaction committed");
                    }
                    catch (Exception ex)
                    {
                        if (tx.HasStarted() && !tx.HasEnded()) tx.RollBack();
                        group.RollBack();

                        outcome.Error = $"{ex.GetType().Name}: {ex.Message}";
                        outcome.Committed = false;
                        _log(LogLevel.Error, $"Write failed — rolled back. {outcome.Error}");
                        _progress.End("Failed — rolled back");
                        return;
                    }
                }

                group.Assimilate();
                outcome.Committed = true;
                _log(LogLevel.Success, "TransactionGroup assimilated — 1 undo step");
            }

            _progress.Report(outcome.Rows.Count);
        }

        private void WriteRow(Element el, ResultRow row, string stamp)
        {
            SetString(el, SdaParameters.LevelBelow, row.LevelBelow);
            SetDouble(el, SdaParameters.OffsetFromBelow, row.OffsetFromBelowFt);
            SetString(el, SdaParameters.LevelAbove, row.LevelAbove);
            SetDouble(el, SdaParameters.OffsetToAbove, row.OffsetToAboveFt);
            SetDouble(el, SdaParameters.BottomElev, row.BottomElevFt);
            SetDouble(el, SdaParameters.TopElev, row.TopElevFt);

            SetString(el, SdaParameters.RoomNumber, row.RoomNumber);
            SetString(el, SdaParameters.RoomName, row.RoomName);
            SetString(el, SdaParameters.RoomLevel, row.RoomLevel);
            SetString(el, SdaParameters.RoomSourceParam, row.RoomSourceText);

            SetString(el, SdaParameters.GridIntersection, row.GridIntersection);
            SetString(el, SdaParameters.GridX, row.GridX);
            SetString(el, SdaParameters.GridY, row.GridY);
            SetDouble(el, SdaParameters.GridOffsetX, row.GridOffsetXFt);
            SetDouble(el, SdaParameters.GridOffsetY, row.GridOffsetYFt);

            SetString(el, SdaParameters.ZoneName, row.ZoneName);
            SetString(el, SdaParameters.Status, row.Status.ToString());
            SetString(el, SdaParameters.Stamp, stamp);
        }

        /// <summary>Writes a string parameter. Silently skips unbound or read-only ones.</summary>
        private static void SetString(Element el, string name, string value)
        {
            Parameter p = el.LookupParameter(name);
            if (p == null || p.IsReadOnly || p.StorageType != StorageType.String) return;
            p.Set(value ?? string.Empty);
        }

        /// <summary>Writes a length parameter. Value is already in internal units (feet).</summary>
        private static void SetDouble(Element el, string name, double valueFt)
        {
            Parameter p = el.LookupParameter(name);
            if (p == null || p.IsReadOnly || p.StorageType != StorageType.Double) return;
            p.Set(valueFt);
        }

        /// <summary>
        /// Yields to the WPF dispatcher so the window repaints and the Cancel button
        /// can be clicked. See the class remarks for why this is necessary.
        /// Uses the dispatcher captured in the ViewModel, never Application.Current.
        /// </summary>
        private void Pump()
        {
            if (_dispatcher == null) return;

            _dispatcher.Invoke(() => { }, DispatcherPriority.Background);
        }
    }
}
