namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Models
{
    /// <summary>How a room was resolved for an element. Written to SDA_Room_Source.</summary>
    public enum RoomSource
    {
        /// <summary>GetRoomAtPoint hit directly at the element anchor.</summary>
        Direct,
        /// <summary>Found by probing upward from the anchor.</summary>
        Above,
        /// <summary>Found by probing downward from the anchor.</summary>
        Below,
        /// <summary>Nearest room centre within the plan radius cap.</summary>
        NearestInPlan,
        /// <summary>No room found by any strategy.</summary>
        None
    }

    /// <summary>Overall outcome per element. Written to SDA_Status.</summary>
    public enum ResolveStatus
    {
        /// <summary>Level, room and grid all resolved directly.</summary>
        Ok,
        /// <summary>Resolved, but at least one value came from a fallback strategy.</summary>
        Fallback,
        /// <summary>At least one required value could not be resolved.</summary>
        NotFound
    }

    /// <summary>Which Revit-side action the single ExternalEvent should perform.</summary>
    public enum SdaRequest
    {
        None,
        /// <summary>Read view, scope boxes, categories, links, levels, grids. No transaction.</summary>
        Scan,
        /// <summary>Bind missing shared parameters. Own transaction.</summary>
        BindParameters,
        /// <summary>Resolve the first N elements and report without writing. No transaction.</summary>
        Preview,
        /// <summary>Full resolve + write. TransactionGroup + single Transaction.</summary>
        Run
    }
}
