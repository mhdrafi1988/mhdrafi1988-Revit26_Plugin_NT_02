using CommunityToolkit.Mvvm.ComponentModel;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Models
{
    /// <summary>One row of the Categories grid. IsSelected is TwoWay bound to the checkbox column.</summary>
    public partial class CategoryRow : ObservableObject
    {
        [ObservableProperty] private bool _isSelected;

        public string Name { get; set; }
        public int CategoryId { get; set; }
        public int InView { get; set; }
        public int InScope { get; set; }

        /// <summary>Set by the filter box; the grid's CollectionView uses it.</summary>
        public bool MatchesFilter(string filter)
            => string.IsNullOrWhiteSpace(filter)
               || (Name?.IndexOf(filter, System.StringComparison.OrdinalIgnoreCase) >= 0);
    }

    /// <summary>One row of the Room Source grid. Single-select (radio semantics).</summary>
    public partial class LinkRoomRow : ObservableObject
    {
        [ObservableProperty] private bool _isSelected;

        public string LinkName { get; set; }
        public int LinkInstanceId { get; set; }
        public int RoomCount { get; set; }
        public int NamedCount { get; set; }

        /// <summary>False for links with zero rooms — the radio is disabled.</summary>
        public bool IsUsable => RoomCount > 0;

        public string StatusText
        {
            get
            {
                if (RoomCount == 0) return "No rooms";
                int unnamed = RoomCount - NamedCount;
                return unnamed > 0 ? $"{unnamed:N0} unnamed" : "Usable";
            }
        }
    }

    /// <summary>One row of the Parameters grid.</summary>
    public partial class ParameterRow : ObservableObject
    {
        [ObservableProperty] private bool _isBound;

        public string Name { get; set; }
        public string TypeLabel { get; set; }
        public string GroupLabel { get; set; } = "Data";
        public bool Required { get; set; }

        public string StatusText => IsBound ? "Bound" : "Missing";

        partial void OnIsBoundChanged(bool value) => OnPropertyChanged(nameof(StatusText));
    }

    /// <summary>
    /// One resolved element. Populated in memory during the resolve pass,
    /// then written to the model in a single transaction. Also feeds the
    /// Live Results and Unresolved grids.
    /// </summary>
    public class ResultRow
    {
        public int ElementId { get; set; }
        public string Category { get; set; }

        public string LevelBelow { get; set; }
        public string LevelAbove { get; set; }
        /// <summary>Internal units (feet). Converted for display and for the parameter write.</summary>
        public double OffsetFromBelowFt { get; set; }
        public double OffsetToAboveFt { get; set; }
        public double BottomElevFt { get; set; }
        public double TopElevFt { get; set; }

        public string RoomNumber { get; set; }
        public string RoomName { get; set; }
        public string RoomLevel { get; set; }
        public RoomSource RoomSource { get; set; } = RoomSource.None;

        public string GridX { get; set; }
        public string GridY { get; set; }
        public double GridOffsetXFt { get; set; }
        public double GridOffsetYFt { get; set; }

        public string ZoneName { get; set; }

        public ResolveStatus Status { get; set; } = ResolveStatus.Ok;
        /// <summary>Human-readable reason shown in the Unresolved grid.</summary>
        public string Reason { get; set; } = string.Empty;

        public string GridIntersection =>
            string.IsNullOrEmpty(GridX) || string.IsNullOrEmpty(GridY)
                ? string.Empty
                : $"{GridX}-{GridY}";

        public string RoomSourceText => RoomSource.ToString();
    }
}
