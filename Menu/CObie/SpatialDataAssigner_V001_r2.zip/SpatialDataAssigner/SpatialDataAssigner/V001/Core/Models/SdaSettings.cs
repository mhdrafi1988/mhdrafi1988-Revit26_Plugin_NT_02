using System.Collections.Generic;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Models
{
    /// <summary>
    /// Per-tool settings POCO. Serialised by System.Text.Json to
    /// %AppData%\Revit26_Plugin\SpatialDataAssigner\settings.json
    /// Loaded on window open, saved on close and after every Run.
    ///
    /// Everything here is a *preference*, never model data — a missing or
    /// corrupt file must degrade to defaults without blocking the tool.
    /// </summary>
    public class SdaSettings
    {
        /// <summary>Bumped when the shape changes so a stale file can be discarded.</summary>
        public int SchemaVersion { get; set; } = 1;

        /// <summary>Last scope box picked, matched by name on reopen.</summary>
        public string LastScopeBoxName { get; set; }

        /// <summary>Prefer the active view's own scope box when it has one.</summary>
        public bool UseViewScopeBox { get; set; } = true;

        /// <summary>Category names last ticked. Matched by name, not id, so it survives a model swap.</summary>
        public List<string> SelectedCategoryNames { get; set; } = new List<string>();

        /// <summary>Link file name last used as the room source.</summary>
        public string LastRoomLinkName { get; set; }

        /// <summary>Plan search cap for the NearestInPlan room fallback, in millimetres.</summary>
        public double RoomSearchRadiusMm { get; set; } = 3000d;

        /// <summary>Probe step for the Above/Below room fallbacks, in millimetres.</summary>
        public double RoomProbeStepMm { get; set; } = 300d;

        /// <summary>
        /// Minimum angle between two grids before they count as an intersecting
        /// pair, in degrees. Guards against picking two near-parallel radial grids.
        /// </summary>
        public double GridPairMinAngleDeg { get; set; } = 25d;

        /// <summary>Shared parameter file used to bind missing SDA parameters.</summary>
        public string SharedParameterFilePath { get; set; }

        /// <summary>Folder chosen once per session for the auto-saved log. Reused thereafter.</summary>
        public string LogFolder { get; set; }

        /// <summary>Window geometry. Never allowed below the design minimum on restore.</summary>
        public double WindowWidth { get; set; } = 1120d;
        public double WindowHeight { get; set; } = 880d;
    }
}
