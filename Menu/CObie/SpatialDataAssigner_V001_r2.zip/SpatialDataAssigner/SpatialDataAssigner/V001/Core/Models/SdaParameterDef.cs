using System.Collections.Generic;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Models
{
    /// <summary>
    /// Definition of one SDA shared parameter: the name the tool writes to,
    /// the storage type it expects, and whether the run is blocked without it.
    /// </summary>
    public class SdaParameterDef
    {
        public string Name { get; }
        public StorageType Storage { get; }
        public bool Required { get; }
        public string Description { get; }

        public SdaParameterDef(string name, StorageType storage, bool required, string description)
        {
            Name = name;
            Storage = storage;
            Required = required;
            Description = description;
        }

        /// <summary>UI label for the Type column.</summary>
        public string TypeLabel => Storage == StorageType.Double ? "Length" : "Text";
    }

    /// <summary>
    /// The canonical 18-parameter set this tool writes.
    ///
    /// ASSUMPTION (flagged in the mockup): all are INSTANCE parameters in the
    /// "Data" group. Lengths are stored in Revit internal units (decimal feet)
    /// and displayed in mm by the project's unit settings — the tool converts
    /// with UnitUtils, it never writes a raw millimetre number.
    ///
    /// COBie note: only Room Number/Name and Level feed native COBie fields
    /// (Component.Space, Space.FloorName). Grid, Zone and the offsets land on
    /// the COBie Attribute sheet. Rename these to your COBie SPF names here if
    /// your handover template expects different keys — nothing else changes.
    /// </summary>
    public static class SdaParameters
    {
        public const string LevelBelow      = "SDA_Level_Below";
        public const string OffsetFromBelow = "SDA_Offset_From_Below";
        public const string LevelAbove      = "SDA_Level_Above";
        public const string OffsetToAbove   = "SDA_Offset_To_Above";
        public const string BottomElev      = "SDA_Bottom_Elev";
        public const string TopElev         = "SDA_Top_Elev";

        public const string RoomNumber      = "SDA_Room_Number";
        public const string RoomName        = "SDA_Room_Name";
        public const string RoomLevel       = "SDA_Room_Level";
        public const string RoomSourceParam = "SDA_Room_Source";

        public const string GridIntersection = "SDA_Grid_Intersection";
        public const string GridX            = "SDA_Grid_X";
        public const string GridY            = "SDA_Grid_Y";
        public const string GridOffsetX      = "SDA_Grid_Offset_X";
        public const string GridOffsetY      = "SDA_Grid_Offset_Y";

        public const string ZoneName        = "SDA_Zone_Name";
        public const string Status          = "SDA_Status";
        public const string Stamp           = "SDA_Stamp";

        /// <summary>Ordered as shown in the Parameters grid.</summary>
        public static IReadOnlyList<SdaParameterDef> All { get; } = new List<SdaParameterDef>
        {
            new SdaParameterDef(LevelBelow,       StorageType.String, true,  "Nearest level at or below the element bottom"),
            new SdaParameterDef(OffsetFromBelow,  StorageType.Double, true,  "Element bottom minus the level-below elevation"),
            new SdaParameterDef(LevelAbove,       StorageType.String, true,  "First level above the element bottom"),
            new SdaParameterDef(OffsetToAbove,    StorageType.Double, true,  "Level-above elevation minus the element bottom"),
            new SdaParameterDef(BottomElev,       StorageType.Double, false, "Project elevation of the element bottom"),
            new SdaParameterDef(TopElev,          StorageType.Double, false, "Project elevation of the element top"),

            new SdaParameterDef(RoomNumber,       StorageType.String, true,  "Room number from the selected source"),
            new SdaParameterDef(RoomName,         StorageType.String, true,  "Room name from the selected source"),
            new SdaParameterDef(RoomLevel,        StorageType.String, false, "Level the resolved room sits on"),
            new SdaParameterDef(RoomSourceParam,  StorageType.String, true,  "Direct / Above / Below / NearestInPlan / None"),

            new SdaParameterDef(GridIntersection, StorageType.String, true,  "Nearest grid intersection, e.g. C-4"),
            new SdaParameterDef(GridX,            StorageType.String, false, "First grid of the nearest pair"),
            new SdaParameterDef(GridY,            StorageType.String, false, "Second grid of the nearest pair"),
            new SdaParameterDef(GridOffsetX,      StorageType.Double, false, "Signed perpendicular distance to the first grid"),
            new SdaParameterDef(GridOffsetY,      StorageType.Double, false, "Signed perpendicular distance to the second grid"),

            new SdaParameterDef(ZoneName,         StorageType.String, true,  "Scope box name used as the zone"),
            new SdaParameterDef(Status,           StorageType.String, true,  "Ok / Fallback / NotFound"),
            new SdaParameterDef(Stamp,            StorageType.String, false, "Date and time this element was last assigned")
        };
    }
}
