using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Services
{
    /// <summary>
    /// Scope box discovery and containment.
    ///
    /// ASSUMPTION (flagged in the mockup): a scope box can be rotated in plan.
    /// Revit's get_BoundingBox(null) returns a box whose Min/Max are expressed in
    /// the box's OWN coordinate system, with a Transform that maps them to model
    /// space. Testing a model point against Min/Max directly is therefore wrong for
    /// any rotated box — we invert the transform first. This is the single most
    /// common bug in scope-box filtering, hence the explicit note.
    /// </summary>
    public class ScopeBoxService
    {
        /// <summary>A scope box plus its cached inverse transform and local bounds.</summary>
        public class ScopeBoxInfo
        {
            public ElementId Id { get; set; }
            public string Name { get; set; }
            public Transform Inverse { get; set; }
            public XYZ LocalMin { get; set; }
            public XYZ LocalMax { get; set; }
            public double RotationDeg { get; set; }
        }

        /// <summary>All scope boxes in the document, ordered by name.</summary>
        public static List<ScopeBoxInfo> Collect(Document doc)
        {
            var result = new List<ScopeBoxInfo>();

            var boxes = new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_VolumeOfInterest)
                .WhereElementIsNotElementType()
                .ToElements();

            foreach (var el in boxes)
            {
                var info = Build(el);
                if (info != null) result.Add(info);
            }

            return result.OrderBy(b => b.Name, StringComparer.OrdinalIgnoreCase).ToList();
        }

        /// <summary>The scope box assigned to a view, or null when the view has none.</summary>
        public static ScopeBoxInfo FromView(Document doc, View view)
        {
            if (view == null) return null;

            Parameter p = view.get_Parameter(BuiltInParameter.VIEWER_VOLUME_OF_INTEREST_CROP);
            if (p == null || p.StorageType != StorageType.ElementId) return null;

            ElementId id = p.AsElementId();
            if (id == null || id == ElementId.InvalidElementId) return null;

            Element el = doc.GetElement(id);
            return el == null ? null : Build(el);
        }

        private static ScopeBoxInfo Build(Element scopeBox)
        {
            try
            {
                BoundingBoxXYZ bb = scopeBox.get_BoundingBox(null);
                if (bb == null) return null;

                Transform t = bb.Transform ?? Transform.Identity;

                // Rotation about Z, reported to the user so a rotated box is never a surprise.
                double rot = Math.Atan2(t.BasisX.Y, t.BasisX.X) * 180d / Math.PI;

                return new ScopeBoxInfo
                {
                    Id = scopeBox.Id,
                    Name = scopeBox.Name,
                    Inverse = t.Inverse,
                    LocalMin = bb.Min,
                    LocalMax = bb.Max,
                    RotationDeg = Math.Round(rot, 1)
                };
            }
            catch
            {
                // A scope box with no geometry is not an error worth stopping for.
                return null;
            }
        }

        /// <summary>
        /// True when a model-space point sits inside the box.
        /// Transforms the point into box-local space first — correct for rotated boxes.
        /// </summary>
        public static bool Contains(ScopeBoxInfo box, XYZ modelPoint, double toleranceFt = 1e-6)
        {
            if (box == null || modelPoint == null) return false;

            XYZ p = box.Inverse.OfPoint(modelPoint);

            return p.X >= box.LocalMin.X - toleranceFt && p.X <= box.LocalMax.X + toleranceFt
                && p.Y >= box.LocalMin.Y - toleranceFt && p.Y <= box.LocalMax.Y + toleranceFt
                && p.Z >= box.LocalMin.Z - toleranceFt && p.Z <= box.LocalMax.Z + toleranceFt;
        }
    }
}
