using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Services
{
    /// <summary>
    /// Resolves the level pair bracketing an element bottom.
    ///
    /// Both offsets are measured from the ELEMENT BOTTOM, as confirmed:
    ///   OffsetFromBelow = bottomZ - levelBelow.Elevation      (>= 0)
    ///   OffsetToAbove   = levelAbove.Elevation - bottomZ      (>  0)
    ///
    /// Levels are cached once per run — a FilteredElementCollector per element
    /// would dominate the runtime on an 8,000-element model.
    /// </summary>
    public class LevelResolver
    {
        public class LevelInfo
        {
            public ElementId Id { get; set; }
            public string Name { get; set; }
            public double Elevation { get; set; }
        }

        private readonly List<LevelInfo> _levels;

        /// <summary>Elevations closer than this count as the same level, in feet (~0.8 mm).</summary>
        private const double ElevationTolerance = 0.0026;

        public IReadOnlyList<LevelInfo> Levels => _levels;

        /// <summary>Names of levels that share an elevation with another — reported as a Warning.</summary>
        public List<string> TiedLevelNames { get; } = new List<string>();

        public LevelResolver(Document doc)
        {
            _levels = new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .Select(l => new LevelInfo { Id = l.Id, Name = l.Name, Elevation = l.Elevation })
                // Sort by elevation, then by name so a tie resolves deterministically
                // to the lowest name — otherwise two runs can disagree.
                .OrderBy(l => l.Elevation)
                .ThenBy(l => l.Name, StringComparer.OrdinalIgnoreCase)
                .ToList();

            DetectTies();
        }

        private void DetectTies()
        {
            for (int i = 1; i < _levels.Count; i++)
            {
                if (Math.Abs(_levels[i].Elevation - _levels[i - 1].Elevation) < ElevationTolerance)
                {
                    if (!TiedLevelNames.Contains(_levels[i - 1].Name)) TiedLevelNames.Add(_levels[i - 1].Name);
                    if (!TiedLevelNames.Contains(_levels[i].Name)) TiedLevelNames.Add(_levels[i].Name);
                }
            }
        }

        public double MinElevation => _levels.Count == 0 ? 0 : _levels[0].Elevation;
        public double MaxElevation => _levels.Count == 0 ? 0 : _levels[_levels.Count - 1].Elevation;

        /// <summary>
        /// Returns the bracketing levels. Either may be null:
        ///   below == null → the element sits beneath the lowest level
        ///   above == null → the element sits at or above the topmost level
        /// </summary>
        public void Resolve(double bottomZ, out LevelInfo below, out LevelInfo above)
        {
            below = null;
            above = null;
            if (_levels.Count == 0) return;

            // Binary search would be marginal here; the linear scan over ~50 levels
            // is cheaper than the branch overhead and far easier to read.
            for (int i = 0; i < _levels.Count; i++)
            {
                if (_levels[i].Elevation <= bottomZ + ElevationTolerance)
                {
                    below = _levels[i];
                }
                else
                {
                    above = _levels[i];
                    break;
                }
            }
        }
    }
}
