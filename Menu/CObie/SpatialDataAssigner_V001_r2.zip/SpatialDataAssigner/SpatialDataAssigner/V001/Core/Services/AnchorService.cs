using Autodesk.Revit.DB;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Services
{
    /// <summary>
    /// Derives the single point used for every spatial lookup on an element.
    ///
    /// ASSUMPTION (flagged in the mockup):
    ///   XY = bounding-box centroid
    ///   Z  = bounding-box minimum, i.e. the element BOTTOM
    /// because every offset Rafi specified is measured from the element bottom,
    /// for the level below AND the level above.
    ///
    /// Curve-driven elements (pipe, duct, cable tray, conduit) get their XY from
    /// the curve midpoint instead — a long diagonal run's bbox centroid can fall
    /// in a different room than the pipe itself ever passes through.
    /// </summary>
    public static class AnchorService
    {
        public class Anchor
        {
            public XYZ Point { get; set; }
            public double BottomZ { get; set; }
            public double TopZ { get; set; }
            public bool FromCurve { get; set; }
            /// <summary>Null when resolved; otherwise why no anchor could be built.</summary>
            public string FailureReason { get; set; }

            public bool IsValid => Point != null && FailureReason == null;
        }

        public static Anchor Resolve(Element element)
        {
            var anchor = new Anchor();

            BoundingBoxXYZ bb = null;
            try
            {
                // null view = model extents, which is what we want; a view-cropped
                // box would shrink with the crop region and move the anchor.
                bb = element.get_BoundingBox(null);
            }
            catch
            {
                bb = null;
            }

            Curve curve = (element.Location as LocationCurve)?.Curve;
            XYZ locPoint = (element.Location as LocationPoint)?.Point;

            if (bb != null)
            {
                anchor.BottomZ = bb.Min.Z;
                anchor.TopZ = bb.Max.Z;

                if (curve != null)
                {
                    XYZ mid = curve.Evaluate(0.5, true);
                    anchor.Point = new XYZ(mid.X, mid.Y, bb.Min.Z);
                    anchor.FromCurve = true;
                }
                else
                {
                    anchor.Point = new XYZ(
                        (bb.Min.X + bb.Max.X) * 0.5,
                        (bb.Min.Y + bb.Max.Y) * 0.5,
                        bb.Min.Z);
                }

                return anchor;
            }

            // No bounding box — fall back to the location, and treat the element as
            // zero-height. Happens with annotation-like or geometry-less families.
            if (curve != null)
            {
                XYZ mid = curve.Evaluate(0.5, true);
                anchor.Point = mid;
                anchor.BottomZ = mid.Z;
                anchor.TopZ = mid.Z;
                anchor.FromCurve = true;
                return anchor;
            }

            if (locPoint != null)
            {
                anchor.Point = locPoint;
                anchor.BottomZ = locPoint.Z;
                anchor.TopZ = locPoint.Z;
                return anchor;
            }

            anchor.FailureReason = "No solid geometry";
            return anchor;
        }
    }
}
