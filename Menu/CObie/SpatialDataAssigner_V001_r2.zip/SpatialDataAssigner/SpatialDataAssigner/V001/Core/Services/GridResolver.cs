using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Services
{
    /// <summary>
    /// Finds the nearest grid INTERSECTION to a point.
    ///
    /// Confirmed: WAMI carries radial and curved grids, so a plain "nearest X grid
    /// + nearest Y grid" split does not hold. The strategy instead is:
    ///   1. Measure the perpendicular distance from the point to every grid curve.
    ///   2. Take the nearest grid as A.
    ///   3. Take the nearest grid whose local direction differs from A by at least
    ///      GridPairMinAngleDeg as B — so two near-parallel radial grids are never
    ///      reported as an intersection.
    /// For arcs the direction is the tangent at the closest parameter, not the chord.
    ///
    /// Grid names are reported in their own order (A then B), not forced into an
    /// X/Y convention that radial grids would not satisfy.
    /// </summary>
    public class GridResolver
    {
        private class GridInfo
        {
            public string Name;
            public Curve Curve;
        }

        private readonly List<GridInfo> _grids = new List<GridInfo>();
        private readonly double _minAngleRad;

        public int GridCount => _grids.Count;
        public int ArcGridCount { get; private set; }
        public int LineGridCount { get; private set; }

        public GridResolver(Document doc, double minPairAngleDeg)
        {
            _minAngleRad = minPairAngleDeg * Math.PI / 180d;

            var grids = new FilteredElementCollector(doc)
                .OfClass(typeof(Grid))
                .Cast<Grid>();

            foreach (Grid g in grids)
            {
                Curve c = null;
                try { c = g.Curve; } catch { c = null; }
                if (c == null) continue;

                _grids.Add(new GridInfo { Name = g.Name, Curve = c });

                if (c is Arc) ArcGridCount++;
                else LineGridCount++;
            }
        }

        public class GridHit
        {
            public string NameA { get; set; }
            public string NameB { get; set; }
            /// <summary>Signed perpendicular distance to grid A, in feet.</summary>
            public double OffsetAFt { get; set; }
            public double OffsetBFt { get; set; }
            public bool Resolved => !string.IsNullOrEmpty(NameA) && !string.IsNullOrEmpty(NameB);
            public string FailureReason { get; set; }
        }

        /// <summary>
        /// Nearest intersecting grid pair. <paramref name="maxDistanceFt"/> caps how far
        /// a grid may be before the element counts as outside the grid extent.
        /// </summary>
        public GridHit Resolve(XYZ point, double maxDistanceFt)
        {
            var hit = new GridHit();
            if (_grids.Count < 2)
            {
                hit.FailureReason = "Fewer than two grids in model";
                return hit;
            }

            // Flatten to plan — grid curves are vertical planes, so the Z of the
            // query point is irrelevant and including it skews every distance.
            XYZ p = new XYZ(point.X, point.Y, 0);

            var measured = new List<(GridInfo grid, double dist, XYZ dir, double signed)>();

            foreach (var g in _grids)
            {
                try
                {
                    Curve flat = FlattenToPlan(g.Curve);
                    IntersectionResult ir = flat.Project(p);
                    if (ir == null) continue;

                    XYZ closest = ir.XYZPoint;
                    double dist = p.DistanceTo(closest);

                    XYZ tangent = flat.ComputeDerivatives(ir.Parameter, false).BasisX.Normalize();
                    // Left-hand normal in plan.
                    XYZ normal = new XYZ(-tangent.Y, tangent.X, 0);
                    double signed = (p - closest).DotProduct(normal);

                    measured.Add((g, dist, tangent, signed));
                }
                catch
                {
                    // One unprojectable grid must not sink the whole run.
                }
            }

            if (measured.Count < 2)
            {
                hit.FailureReason = "Outside grid extent";
                return hit;
            }

            measured.Sort((x, y) => x.dist.CompareTo(y.dist));

            var a = measured[0];
            if (a.dist > maxDistanceFt)
            {
                hit.FailureReason = "Outside grid extent";
                return hit;
            }

            // Nearest grid that is genuinely transverse to A.
            foreach (var cand in measured.Skip(1))
            {
                double angle = a.dir.AngleTo(cand.dir);
                // AngleTo returns 0..pi; a grid at 170 deg is as parallel as one at 10.
                if (angle > Math.PI / 2d) angle = Math.PI - angle;

                if (angle >= _minAngleRad)
                {
                    hit.NameA = a.grid.Name;
                    hit.NameB = cand.grid.Name;
                    hit.OffsetAFt = a.signed;
                    hit.OffsetBFt = cand.signed;
                    return hit;
                }
            }

            hit.FailureReason = "No transverse grid pair";
            return hit;
        }

        /// <summary>Projects a grid curve to the Z=0 plan so distances are planar.</summary>
        private static Curve FlattenToPlan(Curve c)
        {
            if (c is Line line)
            {
                XYZ s = line.GetEndPoint(0);
                XYZ e = line.GetEndPoint(1);
                return Line.CreateBound(new XYZ(s.X, s.Y, 0), new XYZ(e.X, e.Y, 0));
            }

            if (c is Arc arc)
            {
                XYZ s = arc.GetEndPoint(0);
                XYZ e = arc.GetEndPoint(1);
                XYZ m = arc.Evaluate(0.5, true);
                return Arc.Create(
                    new XYZ(s.X, s.Y, 0),
                    new XYZ(e.X, e.Y, 0),
                    new XYZ(m.X, m.Y, 0));
            }

            // Splines and anything exotic: use as-is. Project() still works, the
            // distance just carries a Z component we accept.
            return c;
        }
    }
}
