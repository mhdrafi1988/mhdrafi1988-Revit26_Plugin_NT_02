using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Models;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Services
{
    /// <summary>
    /// Checks which SDA parameters are bound to the selected categories, and binds
    /// the missing ones from a shared parameter file.
    ///
    /// Binding edits the document, so BindMissing runs in its own Transaction —
    /// separate from the Run transaction, because a user may bind once and then
    /// run several times.
    /// </summary>
    public class ParameterBindingService
    {
        /// <summary>Which of the 18 parameters are bound to EVERY selected category.</summary>
        public static List<ParameterRow> CheckBindings(
            Document doc,
            IEnumerable<BuiltInCategory> categories)
        {
            var catList = categories?.ToList() ?? new List<BuiltInCategory>();
            var rows = new List<ParameterRow>();

            var bindings = doc.ParameterBindings;

            foreach (var def in SdaParameters.All)
            {
                bool bound = IsBoundToAll(doc, bindings, def.Name, catList);

                rows.Add(new ParameterRow
                {
                    Name = def.Name,
                    TypeLabel = def.TypeLabel,
                    GroupLabel = "Data",
                    Required = def.Required,
                    IsBound = bound
                });
            }

            return rows;
        }

        private static bool IsBoundToAll(
            Document doc,
            BindingMap bindings,
            string paramName,
            List<BuiltInCategory> categories)
        {
            if (categories.Count == 0) return false;

            DefinitionBindingMapIterator it = bindings.ForwardIterator();
            it.Reset();

            while (it.MoveNext())
            {
                var def = it.Key as Definition;
                if (def == null || !string.Equals(def.Name, paramName, StringComparison.Ordinal))
                    continue;

                var binding = it.Current as ElementBinding;
                if (binding == null) return false;

                // Instance binding only — a type binding would put one value on every
                // instance of a family type, which is wrong for spatial data.
                if (!(binding is InstanceBinding)) return false;

                var boundCats = binding.Categories
                    .Cast<Category>()
                    .Select(c => (BuiltInCategory)c.Id.Value)
                    .ToHashSet();

                return categories.All(c => boundCats.Contains(c));
            }

            return false;
        }

        public class BindResult
        {
            public int BoundCount { get; set; }
            public List<string> Bound { get; } = new List<string>();
            public List<string> NotInFile { get; } = new List<string>();
            public string Error { get; set; }
            public bool Success => Error == null;
        }

        /// <summary>
        /// Binds every SDA parameter missing from the selected categories.
        /// Caller owns the Transaction — this method must be called inside one.
        /// </summary>
        public static BindResult BindMissing(
            Document doc,
            Application app,
            string sharedParamFilePath,
            IEnumerable<BuiltInCategory> categories,
            IEnumerable<string> missingNames)
        {
            var result = new BindResult();
            var missing = missingNames?.ToList() ?? new List<string>();
            if (missing.Count == 0) return result;

            if (string.IsNullOrWhiteSpace(sharedParamFilePath) || !File.Exists(sharedParamFilePath))
            {
                result.Error = "Shared parameter file not found";
                return result;
            }

            // Swap the app-level SPF, bind, then restore — leaving another team's
            // SPF selected after the tool runs is a nasty side effect.
            string previousSpf = app.SharedParametersFilename;

            try
            {
                app.SharedParametersFilename = sharedParamFilePath;
                DefinitionFile defFile = app.OpenSharedParameterFile();

                if (defFile == null)
                {
                    result.Error = "Shared parameter file could not be opened";
                    return result;
                }

                var catSet = app.Create.NewCategorySet();
                foreach (var bic in categories)
                {
                    Category cat = doc.Settings.Categories.get_Item(bic);
                    if (cat != null) catSet.Insert(cat);
                }

                if (catSet.IsEmpty)
                {
                    result.Error = "No valid categories to bind to";
                    return result;
                }

                var allDefs = defFile.Groups
                    .Cast<DefinitionGroup>()
                    .SelectMany(g => g.Definitions.Cast<Definition>())
                    .ToList();

                foreach (string name in missing)
                {
                    var extDef = allDefs.FirstOrDefault(d =>
                        string.Equals(d.Name, name, StringComparison.Ordinal)) as ExternalDefinition;

                    if (extDef == null)
                    {
                        result.NotInFile.Add(name);
                        continue;
                    }

                    InstanceBinding binding = app.Create.NewInstanceBinding(catSet);

                    // BindingMap.Insert signature is (Definition, Binding, ForgeTypeId).
                    // Insert returns false when the definition is already bound;
                    // ReInsert then widens the existing binding to our category set.
                    bool ok = doc.ParameterBindings.Insert(extDef, binding, GroupTypeId.Data);
                    if (!ok)
                        ok = doc.ParameterBindings.ReInsert(extDef, binding, GroupTypeId.Data);

                    if (ok)
                    {
                        result.Bound.Add(name);
                        result.BoundCount++;
                    }
                    else
                    {
                        result.NotInFile.Add(name);
                    }
                }
            }
            catch (Exception ex)
            {
                result.Error = $"{ex.GetType().Name}: {ex.Message}";
            }
            finally
            {
                try { app.SharedParametersFilename = previousSpf; } catch { /* best effort */ }
            }

            return result;
        }
    }
}
