using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Models;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Core.Services
{
    /// <summary>
    /// Resolves the room for an element against a linked (or host) document.
    ///
    /// ASSUMPTION (flagged in the mockup): the link's own transform is inverted
    /// before the point test, so a shared-coordinate offset between the MEP model
    /// and the architectural link does not shift results. This is the second most
    /// common bug in this kind of tool after the scope-box one.
    ///
    /// Fallback order, confirmed: Direct > Above > Below > NearestInPlan.
    /// NearestInPlan uses a coarse XY bucket index over room location points so the
    /// lookup stays near-constant instead of scanning 1,800 rooms per element.
    /// </summary>
    public class RoomResolver
    {
        public class RoomHit
        {
            public string Number { get; set; }
            public string Name { get; set; }
            public string LevelName { get; set; }
            public RoomSource Source { get; set; } = RoomSource.None;
            public bool Resolved => Source != RoomSource.None;
            public string FailureReason { get; set; }
        }

        private class RoomRef
        {
            public string Number;
            public string Name;
            public string LevelName;
            public XYZ HostPoint;   // room location point, already in HOST coordinates
        }

        private readonly Document _roomDoc;
        private readonly Transform _hostToLink;      // host model space -> link space
        private readonly double _probeStepFt;
        private readonly double _probeMaxFt;
        private readonly double _planRadiusFt;

        private readonly Dictionary<(int, int), List<RoomRef>> _buckets
            = new Dictionary<(int, int), List<RoomRef>>();
        private readonly double _bucketSizeFt;

        public int RoomCount { get; }
        public int NamedRoomCount { get; }
        public int UnplacedRoomCount { get; private set; }

        /// <param name="roomDoc">The document holding the rooms (link document, or the host).</param>
        /// <param name="linkTotalTransform">
        /// RevitLinkInstance.GetTotalTransform(), or Transform.Identity when rooms live in the host.
        /// </param>
        public RoomResolver(
            Document roomDoc,
            Transform linkTotalTransform,
            double probeStepFt,
            double probeMaxFt,
            double planRadiusFt)
        {
            _roomDoc = roomDoc;
            _hostToLink = (linkTotalTransform ?? Transform.Identity).Inverse;
            _probeStepFt = Math.Max(probeStepFt, 0.05);
            _probeMaxFt = Math.Max(probeMaxFt, _probeStepFt);
            _planRadiusFt = Math.Max(planRadiusFt, 0.1);
            _bucketSizeFt = Math.Max(_planRadiusFt, 10d);

            Transform linkToHost = linkTotalTransform ?? Transform.Identity;

            var rooms = new FilteredElementCollector(roomDoc)
                .OfClass(typeof(SpatialElement))
                .OfCategory(BuiltInCategory.OST_Rooms)
                .Cast<SpatialElement>()
                .OfType<Room>()
                .ToList();

            RoomCount = rooms.Count;

            foreach (Room r in rooms)
            {
                // Area 0 means unplaced or unenclosed — it can never be hit by a
                // point test, so it is indexed out and reported instead.
                if (r.Area <= 0)
                {
                    UnplacedRoomCount++;
                    continue;
                }

                var lp = r.Location as LocationPoint;
                if (lp == null) continue;

                XYZ hostPt = linkToHost.OfPoint(lp.Point);

                var rr = new RoomRef
                {
                    Number = r.Number ?? string.Empty,
                    Name = r.Name ?? string.Empty,
                    LevelName = r.Level?.Name ?? string.Empty,
                    HostPoint = hostPt
                };

                if (!string.IsNullOrWhiteSpace(rr.Name)) NamedRoomCount++;

                var key = BucketKey(hostPt);
                if (!_buckets.TryGetValue(key, out var list))
                {
                    list = new List<RoomRef>();
                    _buckets[key] = list;
                }
                list.Add(rr);
            }
        }

        private (int, int) BucketKey(XYZ p)
            => ((int)Math.Floor(p.X / _bucketSizeFt), (int)Math.Floor(p.Y / _bucketSizeFt));

        /// <summary>Resolve a room for a host-space anchor point.</summary>
        public RoomHit Resolve(XYZ hostAnchor)
        {
            var hit = new RoomHit();

            // 1. Direct
            Room room = PointTest(hostAnchor);
            if (room != null) return Build(room, RoomSource.Direct);

            // 2. Above — step upward. Catches MEP in a ceiling void above the room.
            for (double dz = _probeStepFt; dz <= _probeMaxFt; dz += _probeStepFt)
            {
                room = PointTest(new XYZ(hostAnchor.X, hostAnchor.Y, hostAnchor.Z + dz));
                if (room != null) return Build(room, RoomSource.Above);
            }

            // 3. Below — step downward. Catches equipment hung under a slab.
            for (double dz = _probeStepFt; dz <= _probeMaxFt; dz += _probeStepFt)
            {
                room = PointTest(new XYZ(hostAnchor.X, hostAnchor.Y, hostAnchor.Z - dz));
                if (room != null) return Build(room, RoomSource.Below);
            }

            // 4. Nearest room centre in plan, capped.
            RoomRef nearest = NearestInPlan(hostAnchor);
            if (nearest != null)
            {
                hit.Number = nearest.Number;
                hit.Name = nearest.Name;
                hit.LevelName = nearest.LevelName;
                hit.Source = RoomSource.NearestInPlan;
                return hit;
            }

            hit.Source = RoomSource.None;
            hit.FailureReason = $"No room in {UnitFormat.FtToMm(_planRadiusFt):N0} mm";
            return hit;
        }

        private Room PointTest(XYZ hostPoint)
        {
            try
            {
                XYZ linkPoint = _hostToLink.OfPoint(hostPoint);
                return _roomDoc.GetRoomAtPoint(linkPoint);
            }
            catch
            {
                return null;
            }
        }

        private RoomRef NearestInPlan(XYZ hostAnchor)
        {
            var (bx, by) = BucketKey(hostAnchor);
            RoomRef best = null;
            double bestDist = double.MaxValue;

            // The 3x3 neighbourhood covers the radius because bucket size >= radius.
            for (int dx = -1; dx <= 1; dx++)
            {
                for (int dy = -1; dy <= 1; dy++)
                {
                    if (!_buckets.TryGetValue((bx + dx, by + dy), out var list)) continue;

                    foreach (var r in list)
                    {
                        double planDist = Math.Sqrt(
                            Math.Pow(r.HostPoint.X - hostAnchor.X, 2) +
                            Math.Pow(r.HostPoint.Y - hostAnchor.Y, 2));

                        if (planDist <= _planRadiusFt && planDist < bestDist)
                        {
                            bestDist = planDist;
                            best = r;
                        }
                    }
                }
            }

            return best;
        }

        private static RoomHit Build(Room room, RoomSource source) => new RoomHit
        {
            Number = room.Number ?? string.Empty,
            Name = room.Name ?? string.Empty,
            LevelName = room.Level?.Name ?? string.Empty,
            Source = source
        };
    }

    /// <summary>Length conversion helpers. Revit internal units are decimal feet.</summary>
    public static class UnitFormat
    {
        public static double MmToFt(double mm) => UnitUtils.ConvertToInternalUnits(mm, UnitTypeId.Millimeters);
        public static double FtToMm(double ft) => UnitUtils.ConvertFromInternalUnits(ft, UnitTypeId.Millimeters);
    }
}
