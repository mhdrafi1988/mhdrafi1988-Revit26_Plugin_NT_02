using System;
using Autodesk.Revit.UI;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Models;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Infrastructure.ExternalEvents
{
    /// <summary>
    /// The single IExternalEventHandler for this tool.
    ///
    /// One handler / one ExternalEvent pair, per the suite convention. The window
    /// has several Revit-side actions (Scan, BindParameters, Preview, Run) but they
    /// are sequential and never overlap, so they are dispatched through one handler
    /// via the Request property rather than four handler/event pairs.
    ///
    /// The handler holds no Revit state of its own — the ViewModel supplies a
    /// callback that does the work with the live UIApplication. This keeps every
    /// Revit API call on the API thread while leaving the logic testable and in
    /// the ViewModel where the UI state lives.
    /// </summary>
    public class SpatialDataAssignerHandler : IExternalEventHandler
    {
        /// <summary>Set by the ViewModel immediately before Event.Raise().</summary>
        public SdaRequest Request { get; set; } = SdaRequest.None;

        /// <summary>Invoked on the Revit API thread. Supplied once by the ViewModel.</summary>
        public Action<UIApplication, SdaRequest> Work { get; set; }

        /// <summary>Raised when Execute throws — the ViewModel surfaces a dialog and logs it.</summary>
        public Action<Exception> OnError { get; set; }

        public void Execute(UIApplication app)
        {
            SdaRequest request = Request;
            Request = SdaRequest.None;

            if (request == SdaRequest.None || Work == null) return;

            try
            {
                Work(app, request);
            }
            catch (Exception ex)
            {
                // Nothing may escape Execute — an unhandled exception here takes
                // Revit down rather than just the tool.
                OnError?.Invoke(ex);
            }
        }

        public string GetName() => "Spatial Data Assigner V001";
    }
}
