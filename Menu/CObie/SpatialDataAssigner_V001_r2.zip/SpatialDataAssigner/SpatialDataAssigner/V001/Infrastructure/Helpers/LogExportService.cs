using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Models;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Services;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Infrastructure.Helpers
{
    /// <summary>
    /// Log auto-save and manual export, plus the unresolved-elements CSV.
    /// Filename convention: {ToolName}_Logs_{yyyy-MM-dd}_{HH-mm}.txt
    ///
    /// Auto-save on completion writes to DefaultLogFolder with no prompt. Only a
    /// manual Export asks for a folder, and then only once per session.
    /// </summary>
    public static class LogExportService
    {
        private const string ToolName = "SpatialDataAssigner";

        /// <summary>
        /// Suite convention: My Documents\Revit26_Plugin\{ToolName}\Logs\
        /// Auto-save writes here with NO folder dialog. Only a manual Export asks.
        /// Version-agnostic by design — no V001 segment in the path.
        /// </summary>
        public static string DefaultLogFolder => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "Revit26_Plugin",
            ToolName,
            "Logs");

        public static string BuildLogFileName()
            => $"{ToolName}_Logs_{DateTime.Now:yyyy-MM-dd}_{DateTime.Now:HH-mm}.txt";

        public static string BuildCsvFileName()
            => $"{ToolName}_Unresolved_{DateTime.Now:yyyy-MM-dd}_{DateTime.Now:HH-mm}.csv";

        /// <summary>Writes the log to folder/filename. Returns the full path, or null with a reason.</summary>
        public static string SaveLog(IEnumerable<LogEntry> entries, string folder, out string note)
        {
            note = null;
            try
            {
                if (string.IsNullOrWhiteSpace(folder))
                {
                    note = "No log folder set — log not auto-saved";
                    return null;
                }

                Directory.CreateDirectory(folder);
                string path = Path.Combine(folder, BuildLogFileName());

                var sb = new StringBuilder();
                sb.AppendLine($"{ToolName} V001 — log");
                sb.AppendLine($"Generated {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                sb.AppendLine(new string('-', 72));

                foreach (var e in entries)
                    sb.AppendLine(e.ToString());

                File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
                note = $"Log saved — {Path.GetFileName(path)}";
                return path;
            }
            catch (Exception ex)
            {
                note = $"Log not saved ({ex.GetType().Name}: {ex.Message})";
                return null;
            }
        }

        /// <summary>Flat text of the whole log, for Copy All.</summary>
        public static string ToClipboardText(IEnumerable<LogEntry> entries)
            => string.Join(Environment.NewLine, entries.Select(e => e.ToString()));

        /// <summary>CSV of unresolved rows, for the QA loop back to the modellers.</summary>
        public static string SaveUnresolvedCsv(IEnumerable<ResultRow> rows, string folder, out string note)
        {
            note = null;
            try
            {
                if (string.IsNullOrWhiteSpace(folder))
                {
                    note = "No folder set — CSV not written";
                    return null;
                }

                Directory.CreateDirectory(folder);
                string path = Path.Combine(folder, BuildCsvFileName());

                var sb = new StringBuilder();
                sb.AppendLine("ElementId,Category,LevelBelow,OffsetFromBelowMm,GridIntersection,RoomSource,Status,Reason");

                foreach (var r in rows)
                {
                    sb.AppendLine(string.Join(",",
                        r.ElementId,
                        Csv(r.Category),
                        Csv(r.LevelBelow),
                        UnitFormat.FtToMm(r.OffsetFromBelowFt).ToString("F0"),
                        Csv(r.GridIntersection),
                        r.RoomSourceText,
                        r.Status,
                        Csv(r.Reason)));
                }

                File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
                note = $"CSV saved — {Path.GetFileName(path)}";
                return path;
            }
            catch (Exception ex)
            {
                note = $"CSV not written ({ex.GetType().Name}: {ex.Message})";
                return null;
            }
        }

        private static string Csv(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            return value.Contains(',') || value.Contains('"')
                ? "\"" + value.Replace("\"", "\"\"") + "\""
                : value;
        }
    }
}
