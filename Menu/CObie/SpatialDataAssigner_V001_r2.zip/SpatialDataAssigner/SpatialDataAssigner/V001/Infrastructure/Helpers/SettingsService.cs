using System;
using System.IO;
using System.Text.Json;
using Revit26_Plugin.SpatialDataAssigner.V001.Core.Models;

namespace Revit26_Plugin.SpatialDataAssigner.V001.Infrastructure.Helpers
{
    /// <summary>
    /// Load/save for SdaSettings at %AppData%\Revit26_Plugin\SpatialDataAssigner\settings.json.
    /// Never throws out of Load or Save — settings are a convenience, not a dependency.
    /// </summary>
    public static class SettingsService
    {
        private const string ToolName = "SpatialDataAssigner";

        private static readonly JsonSerializerOptions JsonOpts = new JsonSerializerOptions
        {
            WriteIndented = true
        };

        public static string SettingsFolder => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "Revit26_Plugin",
            ToolName);

        public static string SettingsPath => Path.Combine(SettingsFolder, "settings.json");

        /// <summary>Returns stored settings, or defaults if absent/unreadable/stale.</summary>
        public static SdaSettings Load(out string note)
        {
            note = null;
            try
            {
                if (!File.Exists(SettingsPath))
                {
                    note = "No settings file — defaults used";
                    return new SdaSettings();
                }

                string json = File.ReadAllText(SettingsPath);
                var loaded = JsonSerializer.Deserialize<SdaSettings>(json, JsonOpts);

                if (loaded == null)
                {
                    note = "Settings file empty — defaults used";
                    return new SdaSettings();
                }

                if (loaded.SchemaVersion != new SdaSettings().SchemaVersion)
                {
                    note = $"Settings schema v{loaded.SchemaVersion} is stale — defaults used";
                    return new SdaSettings();
                }

                note = $"Settings loaded — {SettingsPath}";
                return loaded;
            }
            catch (Exception ex)
            {
                note = $"Settings unreadable ({ex.GetType().Name}) — defaults used";
                return new SdaSettings();
            }
        }

        /// <summary>Writes settings. Returns false and a reason if it could not.</summary>
        public static bool Save(SdaSettings settings, out string note)
        {
            note = null;
            try
            {
                Directory.CreateDirectory(SettingsFolder);
                string json = JsonSerializer.Serialize(settings, JsonOpts);
                File.WriteAllText(SettingsPath, json);
                note = $"Settings saved — {SettingsPath}";
                return true;
            }
            catch (Exception ex)
            {
                note = $"Settings not saved ({ex.GetType().Name}: {ex.Message})";
                return false;
            }
        }
    }
}
